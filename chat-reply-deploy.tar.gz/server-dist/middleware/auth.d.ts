import { Request, Response, NextFunction } from 'express';
export interface JWTPayload {
    userId: string;
    username: string;
}
declare global {
    namespace Express {
        interface Request {
            user?: JWTPayload;
        }
    }
}
export declare function authMiddleware(req: Request, res: Response, next: NextFunction): void;
export declare function signToken(payload: JWTPayload): string;
