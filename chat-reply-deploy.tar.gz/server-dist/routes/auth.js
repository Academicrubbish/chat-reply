"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const uuid_1 = require("uuid");
const db_1 = __importDefault(require("../db"));
const db_2 = require("../db");
const auth_1 = require("../middleware/auth");
const router = (0, express_1.Router)();
// GET /api/auth/status — check if system is initialized
router.get('/status', (_req, res) => {
    const users = db_1.default.prepare('SELECT COUNT(*) as count FROM users').get();
    res.json({ initialized: users.count > 0 });
});
// POST /api/auth/register — user registration (first user becomes admin)
router.post('/register', async (req, res) => {
    const { username, password } = req.body;
    if (!username?.trim() || !password) {
        res.status(400).json({ error: '用户名和密码不能为空' });
        return;
    }
    if (password.length < 6) {
        res.status(400).json({ error: '密码至少6位' });
        return;
    }
    const existing = db_1.default.prepare('SELECT id FROM users WHERE username = ?').get(username.trim());
    if (existing) {
        res.status(409).json({ error: '用户名已存在' });
        return;
    }
    const id = (0, uuid_1.v4)();
    const passwordHash = await (0, db_2.hashPassword)(password);
    const now = Date.now();
    db_1.default.prepare('INSERT INTO users (id, username, password_hash, created_at) VALUES (?, ?, ?, ?)')
        .run(id, username.trim(), passwordHash, now);
    const token = (0, auth_1.signToken)({ userId: id, username: username.trim() });
    res.status(201).json({ token });
});
// POST /api/auth/setup — first-time admin creation (legacy, kept for compat)
router.post('/setup', async (req, res) => {
    const users = db_1.default.prepare('SELECT COUNT(*) as count FROM users').get();
    if (users.count > 0) {
        res.status(403).json({ error: '系统已初始化' });
        return;
    }
    const { username, password } = req.body;
    if (!username?.trim() || !password) {
        res.status(400).json({ error: '用户名和密码不能为空' });
        return;
    }
    if (password.length < 6) {
        res.status(400).json({ error: '密码至少6位' });
        return;
    }
    const id = (0, uuid_1.v4)();
    const passwordHash = await (0, db_2.hashPassword)(password);
    const now = Date.now();
    db_1.default.prepare('INSERT INTO users (id, username, password_hash, created_at) VALUES (?, ?, ?, ?)')
        .run(id, username.trim(), passwordHash, now);
    const token = (0, auth_1.signToken)({ userId: id, username: username.trim() });
    res.status(201).json({ token });
});
// POST /api/auth/login
router.post('/login', async (req, res) => {
    const { username, password } = req.body;
    if (!username || !password) {
        res.status(400).json({ error: '用户名和密码不能为空' });
        return;
    }
    const user = db_1.default.prepare('SELECT * FROM users WHERE username = ?').get(username);
    if (!user) {
        res.status(401).json({ error: '用户名或密码错误' });
        return;
    }
    const valid = await (0, db_2.verifyPassword)(password, user.password_hash);
    if (!valid) {
        res.status(401).json({ error: '用户名或密码错误' });
        return;
    }
    const token = (0, auth_1.signToken)({ userId: user.id, username: user.username });
    res.json({ token });
});
// POST /api/auth/logout
router.post('/logout', (_req, res) => {
    res.json({ success: true });
});
exports.default = router;
