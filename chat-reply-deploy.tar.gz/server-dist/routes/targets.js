"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const uuid_1 = require("uuid");
const db_js_1 = __importDefault(require("../db.js"));
const router = (0, express_1.Router)();
// GET /api/targets
router.get('/', (_req, res) => {
    const targets = db_js_1.default.prepare('SELECT * FROM chat_targets ORDER BY created_at DESC').all();
    res.json(targets);
});
// POST /api/targets
router.post('/', (req, res) => {
    const { name, meet_scene, persona, hobbies, recent_chats, tone_level, goal_intent, forbidden_topics } = req.body;
    if (!name?.trim()) {
        res.status(400).json({ error: '名字不能为空' });
        return;
    }
    const id = (0, uuid_1.v4)();
    const now = Date.now();
    db_js_1.default.prepare(`
    INSERT INTO chat_targets (id, name, meet_scene, persona, hobbies, recent_chats, tone_level, goal_intent, forbidden_topics, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(id, name.trim(), meet_scene || '', persona || '', hobbies || '', recent_chats || '', tone_level || 'moderate', goal_intent || 'pursuing', forbidden_topics || '', now);
    const target = db_js_1.default.prepare('SELECT * FROM chat_targets WHERE id = ?').get(id);
    res.status(201).json(target);
});
// GET /api/targets/:id
router.get('/:id', (req, res) => {
    const target = db_js_1.default.prepare('SELECT * FROM chat_targets WHERE id = ?').get(req.params.id);
    if (!target) {
        res.status(404).json({ error: '聊天对象不存在' });
        return;
    }
    res.json(target);
});
// PUT /api/targets/:id
router.put('/:id', (req, res) => {
    const existing = db_js_1.default.prepare('SELECT * FROM chat_targets WHERE id = ?').get(req.params.id);
    if (!existing) {
        res.status(404).json({ error: '聊天对象不存在' });
        return;
    }
    const { name, meet_scene, persona, hobbies, recent_chats, tone_level, goal_intent, forbidden_topics } = req.body;
    db_js_1.default.prepare(`
    UPDATE chat_targets SET name = ?, meet_scene = ?, persona = ?, hobbies = ?, recent_chats = ?, tone_level = ?, goal_intent = ?, forbidden_topics = ?
    WHERE id = ?
  `).run(name?.trim() ?? existing.name, meet_scene ?? existing.meet_scene, persona ?? existing.persona, hobbies ?? existing.hobbies, recent_chats ?? existing.recent_chats, tone_level ?? existing.tone_level, goal_intent ?? existing.goal_intent, forbidden_topics ?? existing.forbidden_topics, req.params.id);
    const updated = db_js_1.default.prepare('SELECT * FROM chat_targets WHERE id = ?').get(req.params.id);
    res.json(updated);
});
// DELETE /api/targets/:id
router.delete('/:id', (req, res) => {
    const existing = db_js_1.default.prepare('SELECT * FROM chat_targets WHERE id = ?').get(req.params.id);
    if (!existing) {
        res.status(404).json({ error: '聊天对象不存在' });
        return;
    }
    const deleteTx = db_js_1.default.transaction(() => {
        const sessionIds = db_js_1.default.prepare('SELECT id FROM ai_sessions WHERE target_id = ?').all(req.params.id).map(s => s.id);
        if (sessionIds.length > 0) {
            const placeholders = sessionIds.map(() => '?').join(',');
            db_js_1.default.prepare(`DELETE FROM ai_messages WHERE session_id IN (${placeholders})`).run(...sessionIds);
        }
        db_js_1.default.prepare('DELETE FROM ai_sessions WHERE target_id = ?').run(req.params.id);
        db_js_1.default.prepare('DELETE FROM chat_messages WHERE target_id = ?').run(req.params.id);
        db_js_1.default.prepare('DELETE FROM chat_targets WHERE id = ?').run(req.params.id);
    });
    deleteTx();
    res.json({ success: true });
});
exports.default = router;
