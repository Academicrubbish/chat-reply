"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const knowledge_1 = require("../knowledge");
const router = (0, express_1.Router)();
// GET /api/knowledge/units — 获取所有知识单元
router.get('/units', (_req, res) => {
    const units = knowledge_1.knowledgeBase.units.map(u => ({
        id: u.id,
        title: u.title,
        type: u.type,
        modes: u.modes,
        priority: u.priority,
        summary: u.interpretation.split('\n')[0],
    }));
    res.json({ units, total: units.length });
});
// GET /api/knowledge/units/:id — 获取单个知识单元详情
router.get('/units/:id', (req, res) => {
    const unit = (0, knowledge_1.getUnit)(String(req.params.id));
    if (!unit) {
        res.status(404).json({ error: '知识单元不存在' });
        return;
    }
    const relations = (0, knowledge_1.getRelatedUnits)(unit.id);
    res.json({ unit, relations });
});
// GET /api/knowledge/mode/:mode — 获取某模式激活的知识
router.get('/mode/:mode', (req, res) => {
    const mode = req.params.mode;
    const config = (0, knowledge_1.getModeConfig)(mode);
    if (!config) {
        res.status(400).json({ error: '无效模式' });
        return;
    }
    const units = (0, knowledge_1.getUnitsForMode)(mode);
    res.json({
        mode: config.mode,
        label: config.label,
        description: config.description,
        outputTokenBudget: config.outputTokenBudget,
        activatedUnits: units.map(u => ({
            id: u.id,
            title: u.title,
            type: u.type,
            summary: u.interpretation.split('\n')[0],
        })),
    });
});
// GET /api/knowledge/relations — 获取知识关系图
router.get('/relations', (_req, res) => {
    res.json({ relations: knowledge_1.knowledgeBase.relations });
});
// GET /api/knowledge/modes — 获取所有模式配置
router.get('/modes', (_req, res) => {
    res.json({ modes: knowledge_1.knowledgeBase.modes });
});
exports.default = router;
