"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = require("express");
const uuid_1 = require("uuid");
const db_js_1 = __importDefault(require("../db.js"));
const router = (0, express_1.Router)();
// GET /api/targets/:id/sessions
router.get('/targets/:id/sessions', (req, res) => {
    const sessions = db_js_1.default.prepare('SELECT * FROM ai_sessions WHERE target_id = ? ORDER BY created_at DESC').all(req.params.id);
    res.json(sessions);
});
// POST /api/targets/:id/sessions
router.post('/targets/:id/sessions', (req, res) => {
    const targetId = req.params.id;
    const target = db_js_1.default.prepare('SELECT id FROM chat_targets WHERE id = ?').get(targetId);
    if (!target) {
        res.status(404).json({ error: '聊天对象不存在' });
        return;
    }
    const existingCount = db_js_1.default.prepare('SELECT COUNT(*) as count FROM ai_sessions WHERE target_id = ?').get(targetId);
    const id = (0, uuid_1.v4)();
    const title = `#${existingCount.count + 1}`;
    const now = Date.now();
    const createTx = db_js_1.default.transaction(() => {
        db_js_1.default.prepare('UPDATE ai_sessions SET is_active = 0 WHERE target_id = ?').run(targetId);
        db_js_1.default.prepare(`
      INSERT INTO ai_sessions (id, target_id, title, is_active, round_count, context_tokens, plan_goal, plan_next_step, created_at)
      VALUES (?, ?, ?, 1, 0, 0, '', '', ?)
    `).run(id, targetId, title, now);
    });
    createTx();
    const session = db_js_1.default.prepare('SELECT * FROM ai_sessions WHERE id = ?').get(id);
    res.status(201).json(session);
});
// GET /api/sessions/:sessionId/messages
router.get('/sessions/:sessionId/messages', (req, res) => {
    const session = db_js_1.default.prepare('SELECT id FROM ai_sessions WHERE id = ?').get(req.params.sessionId);
    if (!session) {
        res.status(404).json({ error: '辅导窗口不存在' });
        return;
    }
    const messages = db_js_1.default.prepare('SELECT * FROM ai_messages WHERE session_id = ? ORDER BY created_at ASC').all(req.params.sessionId);
    res.json(messages);
});
exports.default = router;
