export declare function getAvailableModels(): {
    provider: string;
    label: string;
    model: string;
}[];
export declare function chatCompletion(messages: Array<{
    role: string;
    content: string;
}>, provider?: string, maxTokens?: number, maxRetries?: number): Promise<string>;
export declare function chatCompletionStream(messages: Array<{
    role: string;
    content: string;
}>, provider?: string, maxRetries?: number, maxTokens?: number): AsyncGenerator<string>;
