import type { KnowledgeUnit, KnowledgeBase, ModeConfig, ModeType } from './types';
export declare const knowledgeBase: KnowledgeBase;
export declare function getUnit(id: string): KnowledgeUnit | undefined;
export declare function getUnitsForMode(mode: ModeType): KnowledgeUnit[];
export declare function getModeConfig(mode: ModeType): ModeConfig | undefined;
export declare function getRelatedUnits(unitId: string): {
    dependsOn: KnowledgeUnit[];
    composesWith: KnowledgeUnit[];
    contrastsWith: KnowledgeUnit[];
};
export declare function getUnitsByType(type: KnowledgeUnit['type']): KnowledgeUnit[];
export declare function getAllUnitIds(): string[];
