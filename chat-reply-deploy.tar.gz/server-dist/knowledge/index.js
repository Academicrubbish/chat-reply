"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.knowledgeBase = void 0;
exports.getUnit = getUnit;
exports.getUnitsForMode = getUnitsForMode;
exports.getModeConfig = getModeConfig;
exports.getRelatedUnits = getRelatedUnits;
exports.getUnitsByType = getUnitsByType;
exports.getAllUnitIds = getAllUnitIds;
const frameworks_1 = require("./frameworks");
const principles_1 = require("./principles");
const scenarios_1 = require("./scenarios");
const concepts_1 = require("./concepts");
const mode_mapping_1 = require("./mode-mapping");
const allUnits = [
    ...frameworks_1.frameworks,
    ...principles_1.principles,
    ...scenarios_1.scenarios,
    ...concepts_1.concepts,
];
exports.knowledgeBase = {
    units: allUnits,
    relations: mode_mapping_1.relations,
    modes: mode_mapping_1.modeConfigs,
};
// 按 ID 查找单元
function getUnit(id) {
    return allUnits.find(u => u.id === id);
}
// 获取指定模式激活的单元
function getUnitsForMode(mode) {
    const config = mode_mapping_1.modeConfigs.find(m => m.mode === mode);
    if (!config)
        return [];
    return config.activatedUnits
        .map(id => allUnits.find(u => u.id === id))
        .filter((u) => u !== undefined);
}
// 获取模式配置
function getModeConfig(mode) {
    return mode_mapping_1.modeConfigs.find(m => m.mode === mode);
}
// 获取指定单元的关联单元
function getRelatedUnits(unitId) {
    const dependsOn = mode_mapping_1.relations
        .filter(r => r.from === unitId && r.type === 'depends-on')
        .map(r => getUnit(r.to))
        .filter((u) => u !== undefined);
    const composesWith = mode_mapping_1.relations
        .filter(r => r.from === unitId && r.type === 'composes-with')
        .map(r => getUnit(r.to))
        .filter((u) => u !== undefined);
    const contrastsWith = mode_mapping_1.relations
        .filter(r => r.from === unitId && r.type === 'contrasts-with')
        .map(r => getUnit(r.to))
        .filter((u) => u !== undefined);
    return { dependsOn, composesWith, contrastsWith };
}
// 按类型获取单元
function getUnitsByType(type) {
    return allUnits.filter(u => u.type === type);
}
// 获取所有单元 ID
function getAllUnitIds() {
    return allUnits.map(u => u.id);
}
