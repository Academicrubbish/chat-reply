export type UnitType = 'framework' | 'principle' | 'scenario' | 'concept';
export type ModeType = 'full' | 'quick' | 'advisor' | 'review';
export type RelationType = 'depends-on' | 'contrasts-with' | 'composes-with';
export interface Trigger {
    scenario: string;
    languageSignals: string[];
    modes: ModeType[];
}
export interface ExecutionStep {
    action: string;
    completionCriteria: string;
    stopCondition?: string;
}
export interface Case {
    title: string;
    problem: string;
    method: string;
    conclusion: string;
    result?: string;
}
export interface KnowledgeUnit {
    id: string;
    title: string;
    type: UnitType;
    modes: ModeType[];
    priority: number;
    reading: string;
    interpretation: string;
    cases: Case[];
    triggers: Trigger[];
    execution: ExecutionStep[];
    boundary: string[];
    dependsOn: string[];
    composesWith: string[];
    contrastsWith: string[];
}
export interface Relation {
    from: string;
    to: string;
    type: RelationType;
    description?: string;
}
export interface ModeConfig {
    mode: ModeType;
    label: string;
    description: string;
    activatedUnits: string[];
    outputTokenBudget: number;
    customInstructions: string;
}
export interface KnowledgeBase {
    units: KnowledgeUnit[];
    relations: Relation[];
    modes: ModeConfig[];
}
