import type { KnowledgeUnit } from './types';
export declare const principles: KnowledgeUnit[];
