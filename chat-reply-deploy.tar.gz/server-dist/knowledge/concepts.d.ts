import type { KnowledgeUnit } from './types';
export declare const concepts: KnowledgeUnit[];
