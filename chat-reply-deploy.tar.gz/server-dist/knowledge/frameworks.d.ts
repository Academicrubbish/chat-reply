import type { KnowledgeUnit } from './types';
export declare const frameworks: KnowledgeUnit[];
