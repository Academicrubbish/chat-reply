import type { KnowledgeUnit } from './types';
export declare const scenarios: KnowledgeUnit[];
