import type { Relation, ModeConfig } from './types';
export declare const relations: Relation[];
export declare const modeConfigs: ModeConfig[];
