"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const dotenv_1 = __importDefault(require("dotenv"));
dotenv_1.default.config();
const express_1 = __importDefault(require("express"));
const cors_1 = __importDefault(require("cors"));
const express_rate_limit_1 = __importDefault(require("express-rate-limit"));
const uuid_1 = require("uuid");
const db_1 = __importStar(require("./db"));
const prompt_1 = require("./prompt");
const llm_1 = require("./llm");
const knowledge_1 = __importDefault(require("./routes/knowledge"));
const bcryptjs_1 = __importDefault(require("bcryptjs"));
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const JWT_SECRET = process.env.JWT_SECRET || 'chat-reply-dev-secret-change-in-prod';
function signToken(payload) {
    return jsonwebtoken_1.default.sign(payload, JWT_SECRET, { expiresIn: '24h' });
}
function authMiddleware(req, res, next) {
    const authHeader = req.headers.authorization;
    if (!authHeader?.startsWith('Bearer ')) {
        res.status(401).json({ error: '认证失败，请重新登录' });
        return;
    }
    try {
        req.user = jsonwebtoken_1.default.verify(authHeader.slice(7), JWT_SECRET);
        next();
    }
    catch {
        res.status(401).json({ error: '认证失败，请重新登录' });
    }
}
const app = (0, express_1.default)();
const PORT = parseInt(process.env.PORT || '3001', 10);
app.use((0, cors_1.default)({
    origin: ['http://localhost:5173', 'http://localhost:5174', 'http://localhost:5175', 'http://127.0.0.1:5173'],
    credentials: true,
}));
app.use(express_1.default.json({ limit: '100kb' }));
app.use((0, express_rate_limit_1.default)({ windowMs: 60000, max: 100 }));
app.get('/api/health', (_req, res) => {
    res.json({ ok: true });
});
// ===== Auth Routes (no JWT required) =====
app.get('/api/auth/status', (_req, res) => {
    const users = db_1.default.prepare('SELECT COUNT(*) as count FROM users').get();
    res.json({ initialized: users.count > 0 });
});
app.post('/api/auth/register', async (req, res) => {
    // Check if registration is allowed
    const regSetting = db_1.default.prepare('SELECT value FROM system_settings WHERE key = ?').get('allow_registration');
    if (regSetting && regSetting.value === 'false') {
        res.status(403).json({ error: '注册已关闭，请联系管理员' });
        return;
    }
    const { username, password } = req.body;
    if (!username?.trim() || !password) {
        res.status(400).json({ error: '用户名和密码不能为空' });
        return;
    }
    if (password.length < 6) {
        res.status(400).json({ error: '密码至少6位' });
        return;
    }
    const existing = db_1.default.prepare('SELECT id FROM users WHERE username = ?').get(username.trim());
    if (existing) {
        res.status(409).json({ error: '用户名已存在' });
        return;
    }
    const id = (0, uuid_1.v4)();
    const passwordHash = await bcryptjs_1.default.hash(password, 10);
    const now = Date.now();
    db_1.default.prepare('INSERT INTO users (id, username, password_hash, created_at) VALUES (?, ?, ?, ?)').run(id, username.trim(), passwordHash, now);
    const token = signToken({ userId: id, username: username.trim() });
    res.status(201).json({ token });
});
app.post('/api/auth/setup', async (req, res) => {
    const users = db_1.default.prepare('SELECT COUNT(*) as count FROM users').get();
    if (users.count > 0) {
        res.status(403).json({ error: '系统已初始化' });
        return;
    }
    const { username, password } = req.body;
    if (!username?.trim() || !password) {
        res.status(400).json({ error: '用户名和密码不能为空' });
        return;
    }
    if (password.length < 6) {
        res.status(400).json({ error: '密码至少6位' });
        return;
    }
    const id = (0, uuid_1.v4)();
    const passwordHash = await bcryptjs_1.default.hash(password, 10);
    const now = Date.now();
    db_1.default.prepare('INSERT INTO users (id, username, password_hash, created_at) VALUES (?, ?, ?, ?)').run(id, username.trim(), passwordHash, now);
    const token = signToken({ userId: id, username: username.trim() });
    res.status(201).json({ token });
});
app.post('/api/auth/login', async (req, res) => {
    const { username, password } = req.body;
    if (!username || !password) {
        res.status(400).json({ error: '用户名和密码不能为空' });
        return;
    }
    const user = db_1.default.prepare('SELECT * FROM users WHERE username = ?').get(username);
    if (!user) {
        res.status(401).json({ error: '用户名或密码错误' });
        return;
    }
    const valid = await bcryptjs_1.default.compare(password, user.password_hash);
    if (!valid) {
        res.status(401).json({ error: '用户名或密码错误' });
        return;
    }
    const token = signToken({ userId: user.id, username: user.username });
    res.json({ token });
});
app.post('/api/auth/logout', (_req, res) => {
    res.json({ success: true });
});
// JWT middleware for all /api/* routes except /api/auth/*
app.use('/api', (req, res, next) => {
    if (req.path.startsWith('/auth'))
        return next();
    if (req.path === '/health')
        return next();
    if (req.path === '/models')
        return next();
    authMiddleware(req, res, next);
});
// Models
app.get('/api/models', (_req, res) => {
    res.json({ models: (0, llm_1.getAvailableModels)() });
});
// Knowledge routes
app.use('/api/knowledge', knowledge_1.default);
// ===== Targets CRUD =====
app.get('/api/targets', (req, res) => {
    const targets = db_1.default.prepare('SELECT * FROM chat_targets WHERE user_id = ? ORDER BY created_at DESC').all(req.user.userId);
    res.json(targets);
});
app.post('/api/targets', (req, res) => {
    const { name, meet_scene, persona, hobbies, recent_chats, tone_level, goal_intent, forbidden_topics } = req.body;
    if (!name?.trim()) {
        res.status(400).json({ error: '名字不能为空' });
        return;
    }
    const id = (0, uuid_1.v4)();
    const now = Date.now();
    db_1.default.prepare(`
    INSERT INTO chat_targets (id, user_id, name, meet_scene, persona, hobbies, recent_chats, tone_level, goal_intent, forbidden_topics, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(id, req.user.userId, name.trim(), meet_scene || '', persona || '', hobbies || '', recent_chats || '', tone_level || 'moderate', goal_intent || 'pursuing', forbidden_topics || '', now);
    const target = db_1.default.prepare('SELECT * FROM chat_targets WHERE id = ?').get(id);
    res.status(201).json(target);
});
app.get('/api/targets/:id', (req, res) => {
    const target = db_1.default.prepare('SELECT * FROM chat_targets WHERE id = ? AND user_id = ?').get(req.params.id, req.user.userId);
    if (!target) {
        res.status(404).json({ error: '聊天对象不存在' });
        return;
    }
    res.json(target);
});
app.put('/api/targets/:id', (req, res) => {
    const existing = db_1.default.prepare('SELECT * FROM chat_targets WHERE id = ? AND user_id = ?').get(req.params.id, req.user.userId);
    if (!existing) {
        res.status(404).json({ error: '聊天对象不存在' });
        return;
    }
    const { name, meet_scene, persona, hobbies, recent_chats, tone_level, goal_intent, forbidden_topics } = req.body;
    db_1.default.prepare(`
    UPDATE chat_targets SET name = ?, meet_scene = ?, persona = ?, hobbies = ?, recent_chats = ?, tone_level = ?, goal_intent = ?, forbidden_topics = ?
    WHERE id = ? AND user_id = ?
  `).run(name?.trim() ?? existing.name, meet_scene ?? existing.meet_scene, persona ?? existing.persona, hobbies ?? existing.hobbies, recent_chats ?? existing.recent_chats, tone_level ?? existing.tone_level, goal_intent ?? existing.goal_intent, forbidden_topics ?? existing.forbidden_topics, req.params.id, req.user.userId);
    res.json(db_1.default.prepare('SELECT * FROM chat_targets WHERE id = ?').get(req.params.id));
});
app.delete('/api/targets/:id', (req, res) => {
    const existing = db_1.default.prepare('SELECT * FROM chat_targets WHERE id = ? AND user_id = ?').get(req.params.id, req.user.userId);
    if (!existing) {
        res.status(404).json({ error: '聊天对象不存在' });
        return;
    }
    db_1.default.transaction(() => {
        const sessionIds = db_1.default.prepare('SELECT id FROM ai_sessions WHERE target_id = ?').all(req.params.id).map((s) => s.id);
        if (sessionIds.length > 0) {
            const placeholders = sessionIds.map(() => '?').join(',');
            db_1.default.prepare(`DELETE FROM reply_selections WHERE session_id IN (${placeholders})`).run(...sessionIds);
            db_1.default.prepare(`DELETE FROM ai_messages WHERE session_id IN (${placeholders})`).run(...sessionIds);
        }
        db_1.default.prepare('DELETE FROM chat_evaluations WHERE target_id = ?').run(req.params.id);
        db_1.default.prepare('DELETE FROM chat_diagnoses WHERE target_id = ?').run(req.params.id);
        db_1.default.prepare('DELETE FROM user_warnings WHERE target_id = ?').run(req.params.id);
        db_1.default.prepare('DELETE FROM ai_sessions WHERE target_id = ?').run(req.params.id);
        db_1.default.prepare('DELETE FROM chat_messages WHERE target_id = ?').run(req.params.id);
        db_1.default.prepare('DELETE FROM chat_targets WHERE id = ?').run(req.params.id);
    })();
    res.json({ success: true });
});
// ===== Messages =====
function verifyTargetOwnership(targetId, userId) {
    return !!db_1.default.prepare('SELECT id FROM chat_targets WHERE id = ? AND user_id = ?').get(targetId, userId);
}
function verifySessionOwnership(sessionId, userId) {
    const session = db_1.default.prepare('SELECT target_id FROM ai_sessions WHERE id = ?').get(sessionId);
    if (!session)
        return false;
    return verifyTargetOwnership(session.target_id, userId);
}
app.get('/api/targets/:id/messages', (req, res) => {
    if (!verifyTargetOwnership(req.params.id, req.user.userId)) {
        res.status(404).json({ error: '聊天对象不存在' });
        return;
    }
    res.json(db_1.default.prepare('SELECT * FROM chat_messages WHERE target_id = ? ORDER BY created_at ASC').all(req.params.id));
});
app.post('/api/targets/:id/messages', (req, res) => {
    if (!verifyTargetOwnership(req.params.id, req.user.userId)) {
        res.status(404).json({ error: '聊天对象不存在' });
        return;
    }
    const { role, text, source, strategy, session_id } = req.body;
    if (!role || !text?.trim()) {
        res.status(400).json({ error: 'role 和 text 必填' });
        return;
    }
    if (!['her', 'me', 'scene'].includes(role)) {
        res.status(400).json({ error: 'role 必须为 her、me 或 scene' });
        return;
    }
    const id = (0, uuid_1.v4)();
    const now = Date.now();
    db_1.default.prepare(`INSERT INTO chat_messages (id, target_id, role, text, source, strategy, session_id, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`)
        .run(id, req.params.id, role, text.trim(), source || '手动输入', strategy || null, session_id || null, now);
    res.status(201).json(db_1.default.prepare('SELECT * FROM chat_messages WHERE id = ?').get(id));
});
app.post('/api/targets/:id/messages/batch', (req, res) => {
    if (!verifyTargetOwnership(req.params.id, req.user.userId)) {
        res.status(404).json({ error: '聊天对象不存在' });
        return;
    }
    const { messages } = req.body;
    if (!Array.isArray(messages) || messages.length === 0) {
        res.status(400).json({ error: 'messages 必须为非空数组' });
        return;
    }
    const insert = db_1.default.prepare(`INSERT INTO chat_messages (id, target_id, role, text, source, strategy, session_id, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`);
    const now = Date.now();
    let count = 0;
    db_1.default.transaction(() => {
        for (let i = 0; i < messages.length; i++) {
            const m = messages[i];
            if (!m.role || !m.text?.trim() || !['her', 'me', 'scene'].includes(m.role))
                continue;
            insert.run((0, uuid_1.v4)(), req.params.id, m.role, m.text.trim(), m.source || '历史记录', m.strategy || null, m.session_id || null, now + i);
            count++;
        }
    })();
    res.status(201).json({ count });
});
app.delete('/api/targets/:id/messages', (req, res) => {
    if (!verifyTargetOwnership(req.params.id, req.user.userId)) {
        res.status(404).json({ error: '聊天对象不存在' });
        return;
    }
    db_1.default.prepare('DELETE FROM chat_messages WHERE target_id = ?').run(req.params.id);
    res.json({ success: true });
});
app.put('/api/messages/:id', (req, res) => {
    const { text } = req.body;
    if (!text?.trim()) {
        res.status(400).json({ error: 'text 必填' });
        return;
    }
    const existing = db_1.default.prepare('SELECT * FROM chat_messages WHERE id = ?').get(req.params.id);
    if (!existing) {
        res.status(404).json({ error: '消息不存在' });
        return;
    }
    if (!verifyTargetOwnership(existing.target_id, req.user.userId)) {
        res.status(404).json({ error: '消息不存在' });
        return;
    }
    db_1.default.prepare('UPDATE chat_messages SET text = ? WHERE id = ?').run(text.trim(), req.params.id);
    res.json(db_1.default.prepare('SELECT * FROM chat_messages WHERE id = ?').get(req.params.id));
});
app.delete('/api/messages/:id', (req, res) => {
    const existing = db_1.default.prepare('SELECT * FROM chat_messages WHERE id = ?').get(req.params.id);
    if (!existing) {
        res.status(404).json({ error: '消息不存在' });
        return;
    }
    if (!verifyTargetOwnership(existing.target_id, req.user.userId)) {
        res.status(404).json({ error: '消息不存在' });
        return;
    }
    db_1.default.prepare('DELETE FROM reply_selections WHERE chat_message_id = ?').run(req.params.id);
    db_1.default.prepare('DELETE FROM chat_messages WHERE id = ?').run(req.params.id);
    res.json({ success: true });
});
// ===== Sessions =====
app.get('/api/targets/:id/sessions', (req, res) => {
    if (!verifyTargetOwnership(req.params.id, req.user.userId)) {
        res.status(404).json({ error: '聊天对象不存在' });
        return;
    }
    res.json(db_1.default.prepare('SELECT * FROM ai_sessions WHERE target_id = ? ORDER BY created_at DESC').all(req.params.id));
});
app.post('/api/targets/:id/sessions', (req, res) => {
    const targetId = req.params.id;
    if (!verifyTargetOwnership(targetId, req.user.userId)) {
        res.status(404).json({ error: '聊天对象不存在' });
        return;
    }
    const existingCount = db_1.default.prepare('SELECT COUNT(*) as count FROM ai_sessions WHERE target_id = ?').get(targetId).count;
    const id = (0, uuid_1.v4)();
    const title = `#${existingCount + 1}`;
    const now = Date.now();
    db_1.default.transaction(() => {
        db_1.default.prepare('UPDATE ai_sessions SET is_active = 0 WHERE target_id = ?').run(targetId);
        db_1.default.prepare(`INSERT INTO ai_sessions (id, target_id, title, is_active, round_count, context_tokens, plan_goal, plan_next_step, created_at) VALUES (?, ?, ?, 1, 0, 0, '', '', ?)`)
            .run(id, targetId, title, now);
    })();
    res.status(201).json(db_1.default.prepare('SELECT * FROM ai_sessions WHERE id = ?').get(id));
});
app.get('/api/sessions/:sessionId/messages', (req, res) => {
    if (!verifySessionOwnership(req.params.sessionId, req.user.userId)) {
        res.status(404).json({ error: '辅导窗口不存在' });
        return;
    }
    res.json(db_1.default.prepare('SELECT * FROM ai_messages WHERE session_id = ? ORDER BY created_at ASC').all(req.params.sessionId));
});
app.get('/api/sessions/:sessionId/selections', (req, res) => {
    if (!verifySessionOwnership(req.params.sessionId, req.user.userId)) {
        res.status(404).json({ error: '辅导窗口不存在' });
        return;
    }
    res.json(db_1.default.prepare('SELECT * FROM reply_selections WHERE session_id = ? ORDER BY created_at ASC').all(req.params.sessionId));
});
app.delete('/api/sessions/:sessionId', (req, res) => {
    if (!verifySessionOwnership(req.params.sessionId, req.user.userId)) {
        res.status(404).json({ error: '辅导窗口不存在' });
        return;
    }
    const session = db_1.default.prepare('SELECT * FROM ai_sessions WHERE id = ?').get(req.params.sessionId);
    db_1.default.transaction(() => {
        db_1.default.prepare('DELETE FROM reply_selections WHERE session_id = ?').run(req.params.sessionId);
        db_1.default.prepare('DELETE FROM ai_messages WHERE session_id = ?').run(req.params.sessionId);
        db_1.default.prepare('DELETE FROM ai_sessions WHERE id = ?').run(req.params.sessionId);
        if (session.is_active === 1) {
            const latest = db_1.default.prepare('SELECT id FROM ai_sessions WHERE target_id = ? ORDER BY created_at DESC LIMIT 1').get(session.target_id);
            if (latest) {
                db_1.default.prepare('UPDATE ai_sessions SET is_active = 1 WHERE id = ?').run(latest.id);
            }
        }
    })();
    res.json({ success: true });
});
// ===== Shared JSON Parser =====
const SAFE_FALLBACK = {
    analysis: {
        stage: '分析中', signal: '模糊', strategy: '安全回复',
        signalText: 'AI 返回格式异常，已降级处理', emotions: [],
        tip: '建议重新生成', favorability: 50, favorabilityReason: '',
    },
    plan: { goal: '维持当前关系', nextStep: '继续对话' },
    replies: [{ id: 1, strategy: '安全回复', text: '嗯嗯，确实', reason: '降级兜底回复' }],
};
function parseJsonSafely(text) {
    // 快速路径：直接解析
    try {
        return JSON.parse(text);
    }
    catch { }
    // ===== 路径 A：保守清洗（不替换中文引号，避免破坏字符串内的 ""）=====
    // 关键：中文引号 "" 在 JSON 字符串值内部是合法 Unicode，不应替换
    // 只在路径 B 才尝试替换中文引号（处理 LLM 用 "" 做 JSON 分隔符的情况）
    let cleaned = text
        .replace(/```(?:json)?\s*/gi, '')
        .replace(/```\s*/g, '')
        .replace(/[\x00-\x1f]/g, '') // 去控制字符（含 raw newline，JSON 不允许）
        .replace(/,\s*([}\]])/g, '$1');
    try {
        return JSON.parse(cleaned);
    }
    catch { }
    // 提取 JSON 块
    const firstBrace = cleaned.indexOf('{');
    const lastBrace = cleaned.lastIndexOf('}');
    if (firstBrace === -1)
        return null;
    let jsonStr = cleaned.slice(firstBrace, lastBrace + 1);
    // 修复中文标点（, : ; 不破坏引号结构）
    let fixed = jsonStr.replace(/，/g, ',').replace(/：/g, ':').replace(/；/g, ';');
    try {
        return JSON.parse(fixed);
    }
    catch { }
    // 截断修复
    try {
        return tryRecoverTruncated(fixed);
    }
    catch { }
    // ===== 路径 B：激进清洗（替换中文引号 "" → ""，可能解决用中文引号做 JSON 分隔符的情况）=====
    let aggressive = jsonStr.replace(/[“”]/g, '"');
    try {
        return JSON.parse(aggressive);
    }
    catch { }
    // 中文标点 + 激进引号
    let aggressiveFixed = aggressive.replace(/，/g, ',').replace(/：/g, ':').replace(/；/g, ';');
    try {
        return JSON.parse(aggressiveFixed);
    }
    catch { }
    // 截断修复
    try {
        return tryRecoverTruncated(aggressiveFixed);
    }
    catch { }
    return null;
}
function tryRecoverTruncated(jsonStr) {
    let recovered = jsonStr;
    const quoteCount = (recovered.match(/"/g) || []).length;
    if (quoteCount % 2 !== 0)
        recovered += '"';
    const ob = (recovered.match(/\[/g) || []).length - (recovered.match(/\]/g) || []).length;
    const oc = (recovered.match(/\{/g) || []).length - (recovered.match(/\}/g) || []).length;
    for (let i = 0; i < ob; i++)
        recovered += ']';
    for (let i = 0; i < oc; i++)
        recovered += '}';
    recovered = recovered.replace(/,\s*([}\]])/g, '$1');
    const result = JSON.parse(recovered);
    console.log('[LLM] Salvaged truncated JSON');
    return result;
}
// ===== Compact Quick Mode Normalizer =====
function normalizeCompactResponse(parsed) {
    // Detect compact format: replies use short keys s/t instead of strategy/text
    if (!parsed.replies?.[0]?.s)
        return parsed; // not compact, return as-is
    return {
        signal: parsed.signal || '模糊',
        fav: parsed.fav ?? 50,
        ctx: parsed.ctx || '',
        analysis: {
            stage: '', signal: parsed.signal || '模糊', strategy: '',
            signalText: '', emotions: [], tip: '',
            favorability: parsed.fav ?? 50, favorabilityReason: '',
        },
        replies: (parsed.replies || []).map((r, i) => ({
            id: i + 1, strategy: r.s || '安全回复', text: r.t || '', reason: '',
        })),
    };
}
// ===== Incremental Reply Extractor (for progressive streaming) =====
function extractNewReplies(raw, alreadySent) {
    const repliesIdx = raw.indexOf('"replies"');
    if (repliesIdx === -1)
        return [];
    const arrStart = raw.indexOf('[', repliesIdx);
    if (arrStart === -1)
        return [];
    let depth = 0, inStr = false, esc = false, objStart = -1;
    const found = [];
    for (let i = arrStart + 1; i < raw.length; i++) {
        const ch = raw[i];
        if (esc) {
            esc = false;
            continue;
        }
        if (ch === '\\' && inStr) {
            esc = true;
            continue;
        }
        if (ch === '"') {
            inStr = !inStr;
            continue;
        }
        if (inStr)
            continue;
        if (ch === '{') {
            if (depth === 0)
                objStart = i;
            depth++;
        }
        else if (ch === '}') {
            depth--;
            if (depth === 0 && objStart !== -1) {
                try {
                    found.push(JSON.parse(raw.slice(objStart, i + 1)));
                }
                catch { }
                objStart = -1;
            }
        }
        else if (ch === ']' && depth === 0)
            break;
    }
    return found.slice(alreadySent);
}
// ===== AI Generate Core =====
app.post('/api/sessions/:sessionId/generate', async (req, res) => {
    try {
        const { herMessage, provider, mode } = req.body;
        if (!herMessage?.trim()) {
            res.status(400).json({ error: '消息不能为空' });
            return;
        }
        const isQuick = mode === 'quick';
        const session = db_1.default.prepare('SELECT * FROM ai_sessions WHERE id = ?').get(req.params.sessionId);
        if (!session || !verifyTargetOwnership(session.target_id, req.user.userId)) {
            res.status(404).json({ error: '辅导窗口不存在' });
            return;
        }
        const target = db_1.default.prepare('SELECT * FROM chat_targets WHERE id = ? AND user_id = ?').get(session.target_id, req.user.userId);
        if (!target) {
            res.status(404).json({ error: '聊天对象不存在' });
            return;
        }
        const now = Date.now();
        const recentMessages = db_1.default.prepare('SELECT * FROM chat_messages WHERE target_id = ? ORDER BY created_at DESC LIMIT 15').all(target.id).reverse();
        const aiMessages = db_1.default.prepare('SELECT * FROM ai_messages WHERE session_id = ? ORDER BY created_at DESC LIMIT 10').all(session.id).reverse();
        // Build feedback preferences from ai_messages
        const feedbackPrefs = aiMessages
            .filter((m) => m.role === 'user' && m.content.includes('反馈'))
            .map((m) => { try {
            return JSON.parse(m.content);
        }
        catch {
            return null;
        } })
            .filter(Boolean)
            .map((f) => `用户对${f.strategy}策略反馈${f.rating === 'thumbs_up' ? '👍' : '👎'}`)
            .join('；');
        // SSE headers
        res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', 'Connection': 'keep-alive' });
        let clientDisconnected = false;
        req.on('close', () => { clientDisconnected = true; });
        const send = (event, data) => { if (!clientDisconnected) {
            try {
                res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);
            }
            catch { }
        } };
        const heartbeatTimer = setInterval(() => { send('heartbeat', { ts: Date.now() }); }, 2000);
        // ===== Diagnosis-first: ensure diagnosis exists =====
        let diagnosis = null;
        if (target.active_diagnosis_id) {
            const d = db_1.default.prepare('SELECT * FROM chat_diagnoses WHERE id = ?').get(target.active_diagnosis_id);
            if (d) {
                diagnosis = {
                    ...d,
                    warnings: JSON.parse(d.warnings_json || '[]'),
                    knowledgeIds: JSON.parse(d.knowledge_ids || '[]'),
                };
            }
        }
        // No diagnosis: auto-diagnose first (non-SSE, internal call)
        if (!diagnosis) {
            send('step', { step: 'auto_diagnosing' });
            try {
                diagnosis = await runDiagnosisInternal(target, recentMessages, provider || 'zhipu');
            }
            catch (diagErr) {
                console.error('[Auto-Diagnose Error]', diagErr.message);
                // Create fallback diagnosis so frontend always has something to show
                diagnosis = {
                    id: '',
                    target_id: target.id,
                    attitude_level: '无法判断',
                    language_pattern: '无法判断',
                    emotion_type: '未知',
                    emotion_valence: '中性',
                    stage: '信息不足',
                    upgrade_ready: false,
                    upgrade_reason: '',
                    warnings: ['自动诊断暂时不可用，请稍后手动重新诊断'],
                    action: '维持当前关系',
                    strategy: '先进行轻松对话，积累更多数据后再诊断',
                    knowledgeIds: [],
                    created_at: Date.now(),
                };
            }
            send('diagnosis_ready', { diagnosis });
            if (diagnosis.action || diagnosis.strategy) {
                send('plan', { goal: diagnosis.action, nextStep: diagnosis.strategy });
            }
        }
        // Build prompt params with diagnosis
        const promptParams = { target, recentMessages: recentMessages, planGoal: session.plan_goal, planNextStep: session.plan_next_step, feedbackPreferences: feedbackPrefs, diagnosis };
        const baseMessages = isQuick
            ? (0, prompt_1.buildQuickMessages)({ ...promptParams, contextSummary: session.context_summary || '' })
            : (0, prompt_1.buildFullMessagesOptimized)(promptParams);
        const conversationMessages = [...baseMessages];
        if (!isQuick) {
            for (const aiMsg of aiMessages) {
                conversationMessages.push({ role: aiMsg.role, content: aiMsg.content });
            }
        }
        conversationMessages.push({ role: 'user', content: `对方的最新消息是：${herMessage}` });
        const totalText = conversationMessages.map(m => m.content).join('');
        const estimatedTokens = Math.ceil(Buffer.byteLength(totalText, 'utf-8') / 2);
        // Stream reply generation
        if (!isQuick)
            send('step', { step: 'analyze' });
        let raw = '';
        send('step', { step: 'generating' });
        try {
            let sentReplyCount = 0;
            for await (const delta of (0, llm_1.chatCompletionStream)(conversationMessages, provider || 'zhipu', 1, isQuick ? 4096 : 8192)) {
                raw += delta;
                if (clientDisconnected)
                    break;
                send('delta', { text: delta });
                if (isQuick) {
                    const newReplies = extractNewReplies(raw, sentReplyCount);
                    for (const r of newReplies) {
                        const reply = r.s !== undefined
                            ? { id: sentReplyCount + 1, strategy: r.s || '安全回复', text: r.t || '', reason: '' }
                            : r;
                        send('reply_ready', { reply, index: sentReplyCount });
                        sentReplyCount++;
                    }
                }
            }
        }
        finally {
            clearInterval(heartbeatTimer);
        }
        if (!isQuick)
            send('step', { step: 'parsing' });
        console.log('[LLM Raw] length:', raw.length, 'preview:', raw.slice(0, 300));
        let parsed = parseJsonSafely(raw);
        if (!parsed) {
            console.error('[LLM Parse Error] Full raw output:\n', raw);
            // Send debug info to frontend so user can inspect in browser console
            send('debug_raw', { source: 'generate', rawLength: raw.length, rawPreview: raw.slice(0, 800) });
            parsed = SAFE_FALLBACK;
            console.log('[LLM] Using safe fallback response');
        }
        // Quick mode: normalize compact format
        let quickCtx = '';
        if (isQuick) {
            const normalized = normalizeCompactResponse(parsed);
            quickCtx = normalized.ctx || '';
            parsed = normalized;
        }
        console.log('[LLM Parsed] keys:', Object.keys(parsed), 'replies count:', parsed.replies?.length ?? 0);
        // Send structured events (diagnosis-aware: only replies, no analysis/plan needed)
        if (!isQuick) {
            send('replies', parsed.replies || []);
        }
        const maxTokens = 8000;
        const contextUsage = { estimatedTokens, maxTokens, percentage: Math.min(Math.round(estimatedTokens / maxTokens * 100), 100) };
        // Save to DB
        const roundId = (0, uuid_1.v4)();
        const userAiMsgId = (0, uuid_1.v4)();
        const assistantAiMsgId = (0, uuid_1.v4)();
        db_1.default.transaction(() => {
            db_1.default.prepare('INSERT INTO ai_messages (id, session_id, role, content, round_id, version, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)')
                .run(userAiMsgId, session.id, 'user', JSON.stringify({ herMessage }), roundId, 1, now);
            db_1.default.prepare('INSERT INTO ai_messages (id, session_id, role, content, round_id, version, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)')
                .run(assistantAiMsgId, session.id, 'assistant', JSON.stringify(parsed), roundId, 1, now + 1);
            const newRoundCount = session.round_count + 1;
            const newPlanGoal = diagnosis?.action || session.plan_goal;
            const newPlanNextStep = diagnosis?.strategy || session.plan_next_step;
            if (isQuick) {
                db_1.default.prepare('UPDATE ai_sessions SET round_count = ?, context_tokens = ?, plan_goal = ?, plan_next_step = ?, context_summary = ?, diagnosis_id = ? WHERE id = ?')
                    .run(newRoundCount, estimatedTokens, newPlanGoal, newPlanNextStep, quickCtx || session.context_summary, diagnosis?.id || null, session.id);
            }
            else {
                db_1.default.prepare('UPDATE ai_sessions SET round_count = ?, context_tokens = ?, plan_goal = ?, plan_next_step = ?, diagnosis_id = ? WHERE id = ?')
                    .run(newRoundCount, estimatedTokens, newPlanGoal, newPlanNextStep, diagnosis?.id || null, session.id);
            }
        })();
        send('done', { contextUsage, roundId, version: 1 });
        res.end();
    }
    catch (err) {
        console.error('Generate error:', err);
        try {
            res.write(`event: error\ndata: ${JSON.stringify({ message: err.message || 'AI 服务异常' })}\n\n`);
            res.end();
        }
        catch { /* connection already closed */ }
    }
});
// ===== Reply Actions =====
app.post('/api/sessions/:sessionId/select-reply', (req, res) => {
    const { replyId, aiMessageId } = req.body;
    const session = db_1.default.prepare('SELECT * FROM ai_sessions WHERE id = ?').get(req.params.sessionId);
    if (!session || !verifyTargetOwnership(session.target_id, req.user.userId)) {
        res.status(404).json({ error: '辅导窗口不存在' });
        return;
    }
    // Get the specific assistant message (version-aware) or fall back to last one
    let aiMsg;
    if (aiMessageId) {
        aiMsg = db_1.default.prepare('SELECT * FROM ai_messages WHERE id = ? AND session_id = ? AND role = ?')
            .get(aiMessageId, req.params.sessionId, 'assistant');
    }
    else {
        aiMsg = db_1.default.prepare('SELECT * FROM ai_messages WHERE session_id = ? AND role = ? ORDER BY created_at DESC LIMIT 1')
            .get(req.params.sessionId, 'assistant');
    }
    if (!aiMsg) {
        res.status(400).json({ error: '没有可用的回复' });
        return;
    }
    let parsed;
    try {
        parsed = JSON.parse(aiMsg.content);
    }
    catch {
        res.status(500).json({ error: '解析失败' });
        return;
    }
    const reply = (parsed.replies || []).find((r) => r.id === replyId);
    if (!reply) {
        res.status(400).json({ error: '回复不存在' });
        return;
    }
    const chatMsgId = (0, uuid_1.v4)();
    db_1.default.prepare(`INSERT INTO chat_messages (id, target_id, role, text, source, strategy, session_id, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`)
        .run(chatMsgId, session.target_id, 'me', reply.text, 'AI建议', reply.strategy, session.id, Date.now());
    // Track selection explicitly
    db_1.default.prepare(`INSERT INTO reply_selections (id, session_id, ai_message_id, reply_id, reply_text, strategy, chat_message_id, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`)
        .run((0, uuid_1.v4)(), req.params.sessionId, aiMsg.id, replyId, reply.text, reply.strategy, chatMsgId, Date.now());
    res.json({ success: true, messageId: chatMsgId });
});
app.post('/api/sessions/:sessionId/custom-reply', (req, res) => {
    const { text } = req.body;
    if (!text?.trim()) {
        res.status(400).json({ error: '回复不能为空' });
        return;
    }
    const session = db_1.default.prepare('SELECT * FROM ai_sessions WHERE id = ?').get(req.params.sessionId);
    if (!session || !verifyTargetOwnership(session.target_id, req.user.userId)) {
        res.status(404).json({ error: '辅导窗口不存在' });
        return;
    }
    const id = (0, uuid_1.v4)();
    db_1.default.prepare(`INSERT INTO chat_messages (id, target_id, role, text, source, strategy, session_id, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`)
        .run(id, session.target_id, 'me', text.trim(), '自定义回复', null, session.id, Date.now());
    res.json({ success: true, messageId: id });
});
app.post('/api/sessions/:sessionId/regenerate', async (req, res) => {
    try {
        const { preferredStrategy, provider, mode, roundId: requestedRoundId } = req.body;
        const session = db_1.default.prepare('SELECT * FROM ai_sessions WHERE id = ?').get(req.params.sessionId);
        if (!session || !verifyTargetOwnership(session.target_id, req.user.userId)) {
            res.status(404).json({ error: '辅导窗口不存在' });
            return;
        }
        const isQuick = mode === 'quick';
        // Determine round_id and next version
        let roundId;
        let nextVersion;
        if (requestedRoundId) {
            roundId = requestedRoundId;
            const maxVer = db_1.default.prepare('SELECT MAX(version) as max_ver FROM ai_messages WHERE session_id = ? AND round_id = ?')
                .get(session.id, roundId);
            nextVersion = (maxVer?.max_ver || 0) + 1;
        }
        else {
            const lastAssistant = db_1.default.prepare('SELECT round_id, version FROM ai_messages WHERE session_id = ? AND role = ? ORDER BY created_at DESC LIMIT 1')
                .get(session.id, 'assistant');
            roundId = lastAssistant?.round_id || (0, uuid_1.v4)();
            nextVersion = (lastAssistant?.version || 0) + 1;
        }
        // Append user message requesting regeneration
        db_1.default.prepare('INSERT INTO ai_messages (id, session_id, role, content, round_id, version, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)')
            .run((0, uuid_1.v4)(), session.id, 'user', JSON.stringify({ type: 'regenerate', preferredStrategy }), roundId, nextVersion, Date.now());
        // Re-run generate logic with last her message
        const lastHerMsg = db_1.default.prepare(`SELECT * FROM chat_messages WHERE target_id = ? AND role = 'her' ORDER BY created_at DESC LIMIT 1`)
            .get(session.target_id);
        if (!lastHerMsg) {
            res.status(400).json({ error: '没有对方消息' });
            return;
        }
        const target = db_1.default.prepare('SELECT * FROM chat_targets WHERE id = ? AND user_id = ?').get(session.target_id, req.user.userId);
        if (!target) {
            res.status(404).json({ error: '聊天对象不存在' });
            return;
        }
        const recentMessages = db_1.default.prepare('SELECT * FROM chat_messages WHERE target_id = ? ORDER BY created_at DESC LIMIT 15').all(session.target_id).reverse();
        const aiMessages = db_1.default.prepare('SELECT * FROM ai_messages WHERE session_id = ? ORDER BY created_at DESC LIMIT 10').all(session.id).reverse();
        // SSE headers
        res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', 'Connection': 'keep-alive' });
        let clientDisconnected = false;
        req.on('close', () => { clientDisconnected = true; });
        const send = (event, data) => { if (!clientDisconnected) {
            try {
                res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);
            }
            catch { }
        } };
        const heartbeatTimer = setInterval(() => { send('heartbeat', { ts: Date.now() }); }, 2000);
        // ===== Diagnosis-first: ensure diagnosis exists =====
        let diagnosis = null;
        if (target.active_diagnosis_id) {
            const d = db_1.default.prepare('SELECT * FROM chat_diagnoses WHERE id = ?').get(target.active_diagnosis_id);
            if (d) {
                diagnosis = { ...d, warnings: JSON.parse(d.warnings_json || '[]'), knowledgeIds: JSON.parse(d.knowledge_ids || '[]') };
            }
        }
        if (!diagnosis) {
            send('step', { step: 'auto_diagnosing' });
            try {
                diagnosis = await runDiagnosisInternal(target, recentMessages, provider || 'zhipu');
            }
            catch (diagErr) {
                console.error('[Auto-Diagnose Error]', diagErr.message);
                diagnosis = {
                    id: '',
                    target_id: target.id,
                    attitude_level: '无法判断',
                    language_pattern: '无法判断',
                    emotion_type: '未知',
                    emotion_valence: '中性',
                    stage: '信息不足',
                    upgrade_ready: false,
                    upgrade_reason: '',
                    warnings: ['自动诊断暂时不可用，请稍后手动重新诊断'],
                    action: '维持当前关系',
                    strategy: '先进行轻松对话，积累更多数据后再诊断',
                    knowledgeIds: [],
                    created_at: Date.now(),
                };
            }
            send('diagnosis_ready', { diagnosis });
            if (diagnosis.action || diagnosis.strategy) {
                send('plan', { goal: diagnosis.action, nextStep: diagnosis.strategy });
            }
        }
        const promptParams = { target, recentMessages: recentMessages, planGoal: session.plan_goal, planNextStep: session.plan_next_step, feedbackPreferences: '', diagnosis };
        const baseMessages = isQuick
            ? (0, prompt_1.buildQuickMessages)({ ...promptParams, contextSummary: session.context_summary || '' })
            : (0, prompt_1.buildFullMessagesOptimized)(promptParams);
        const conversationMessages = [...baseMessages];
        if (!isQuick) {
            for (const aiMsg of aiMessages) {
                conversationMessages.push({ role: aiMsg.role, content: aiMsg.content });
            }
        }
        conversationMessages.push({ role: 'user', content: `对方的最新消息是：${lastHerMsg.text}` });
        if (!isQuick)
            send('step', { step: 'analyze' });
        send('step', { step: 'generating' });
        let raw = '';
        let sentReplyCount = 0;
        try {
            for await (const delta of (0, llm_1.chatCompletionStream)(conversationMessages, provider || 'zhipu', 1, isQuick ? 4096 : 8192)) {
                raw += delta;
                if (clientDisconnected)
                    break;
                send('delta', { text: delta });
                if (isQuick) {
                    const newReplies = extractNewReplies(raw, sentReplyCount);
                    for (const r of newReplies) {
                        const reply = r.s !== undefined
                            ? { id: sentReplyCount + 1, strategy: r.s || '安全回复', text: r.t || '', reason: '' }
                            : r;
                        send('reply_ready', { reply, index: sentReplyCount });
                        sentReplyCount++;
                    }
                }
            }
        }
        finally {
            clearInterval(heartbeatTimer);
        }
        if (!isQuick)
            send('step', { step: 'parsing' });
        let parsed = parseJsonSafely(raw);
        if (!parsed) {
            console.error('[Regen Parse Error] All fallback attempts failed. Raw:', raw.slice(0, 500));
            parsed = SAFE_FALLBACK;
        }
        let quickCtx = '';
        if (isQuick) {
            const normalized = normalizeCompactResponse(parsed);
            quickCtx = normalized.ctx || '';
            parsed = normalized;
        }
        // Send structured events (diagnosis-aware: only replies)
        if (!isQuick) {
            send('replies', parsed.replies || []);
        }
        // Save to DB
        const totalText = conversationMessages.map(m => m.content).join('');
        const estimatedTokens = Math.ceil(Buffer.byteLength(totalText, 'utf-8') / 2);
        db_1.default.prepare('INSERT INTO ai_messages (id, session_id, role, content, round_id, version, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)')
            .run((0, uuid_1.v4)(), session.id, 'assistant', JSON.stringify(parsed), roundId, nextVersion, Date.now());
        if (isQuick) {
            db_1.default.prepare('UPDATE ai_sessions SET round_count = round_count + 1, context_tokens = ?, context_summary = ?, diagnosis_id = ? WHERE id = ?')
                .run(estimatedTokens, quickCtx || session.context_summary, diagnosis?.id || null, session.id);
        }
        else {
            db_1.default.prepare('UPDATE ai_sessions SET round_count = round_count + 1, context_tokens = ?, diagnosis_id = ? WHERE id = ?')
                .run(estimatedTokens, diagnosis?.id || null, session.id);
        }
        send('done', { contextUsage: { estimatedTokens, maxTokens: 8000, percentage: Math.min(Math.round(estimatedTokens / 8000 * 100), 100) }, roundId, version: nextVersion });
        res.end();
    }
    catch (err) {
        console.error('Regenerate error:', err);
        try {
            res.write(`event: error\ndata: ${JSON.stringify({ message: err.message || 'AI 服务异常' })}\n\n`);
            res.end();
        }
        catch { /* connection already closed */ }
    }
});
// ===== Diagnosis API (target-scoped, diagnosis-first architecture) =====
// POST /api/targets/:targetId/diagnose — SSE stream, target-scoped diagnosis
app.post('/api/targets/:targetId/diagnose', async (req, res) => {
    try {
        const { provider } = req.body;
        const target = db_1.default.prepare('SELECT * FROM chat_targets WHERE id = ? AND user_id = ?').get(req.params.targetId, req.user.userId);
        if (!target) {
            res.status(404).json({ error: '聊天对象不存在' });
            return;
        }
        const recentMessages = db_1.default.prepare('SELECT * FROM chat_messages WHERE target_id = ? ORDER BY created_at DESC LIMIT 30').all(target.id).reverse();
        if (recentMessages.length < 2) {
            res.status(400).json({ error: '聊天记录太少，至少需要2条消息才能诊断' });
            return;
        }
        // SSE headers
        res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', 'Connection': 'keep-alive' });
        let clientDisconnected = false;
        req.on('close', () => { clientDisconnected = true; });
        const send = (event, data) => { if (!clientDisconnected) {
            try {
                res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);
            }
            catch { }
        } };
        send('step', { step: 'analyzing' });
        const systemPrompt = (0, prompt_1.buildAdvisorPrompt)({ target, recentMessages: recentMessages, contextSummary: '' });
        const conversationMessages = [
            { role: 'system', content: systemPrompt },
            { role: 'user', content: '请分析对方当前的状态' },
        ];
        let raw = '';
        const heartbeatTimer = setInterval(() => { send('heartbeat', { ts: Date.now() }); }, 2000);
        try {
            for await (const delta of (0, llm_1.chatCompletionStream)(conversationMessages, provider || 'zhipu', 1, 16384)) {
                raw += delta;
                if (clientDisconnected)
                    break;
                send('delta', { text: delta });
            }
        }
        finally {
            clearInterval(heartbeatTimer);
        }
        send('step', { step: 'parsing' });
        let parsed = parseJsonSafely(raw);
        if (!parsed) {
            console.error('[Diagnose Parse Error] Full raw output:\n', raw);
            send('debug_raw', { source: 'diagnose', rawLength: raw.length, rawPreview: raw.slice(0, 800) });
            res.write(`event: error\ndata: ${JSON.stringify({ message: '诊断结果解析失败，请重试', rawLength: raw.length, rawPreview: raw.slice(0, 500) })}\n\n`);
            res.end();
            return;
        }
        // Validate: must have attitude or at minimum some structure
        if (!parsed.attitude?.level || !parsed.emotion?.type) {
            console.error('[Diagnose Invalid] LLM returned unexpected structure:', JSON.stringify(parsed).slice(0, 500));
            // Graceful degradation: fill in missing fields with defaults instead of erroring
            parsed = {
                ...parsed,
                attitude: parsed.attitude || {},
                emotion: parsed.emotion || {},
                diagnosis: parsed.diagnosis || {},
                nextStep: parsed.nextStep || {},
            };
            parsed.attitude.level = parsed.attitude.level || '回应';
            parsed.attitude.languagePattern = parsed.attitude.languagePattern || '无法判断';
            parsed.attitude.detail = parsed.attitude.detail || '数据不足以做出准确判断';
            parsed.attitude.evidence = parsed.attitude.evidence || '';
            parsed.emotion.type = parsed.emotion.type || '未知';
            parsed.emotion.valence = parsed.emotion.valence || '中性';
            parsed.emotion.detail = parsed.emotion.detail || '情绪状态不明确';
            parsed.emotion.evidence = parsed.emotion.evidence || '';
            console.log('[Diagnose] Using degraded fallback structure');
        }
        // Save to chat_diagnoses
        const diag = parsed.diagnosis || {};
        const diagId = (0, uuid_1.v4)();
        const now = Date.now();
        db_1.default.prepare(`INSERT INTO chat_diagnoses (id, session_id, target_id, attitude_level, language_pattern, emotion_type, emotion_valence, stage, upgrade_ready, upgrade_reason, warnings_json, action, strategy, knowledge_ids, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
            .run(diagId, null, target.id, parsed.attitude?.level || '', parsed.attitude?.languagePattern || '', parsed.emotion?.type || '', parsed.emotion?.valence || '', diag.stage || '', diag.upgradeReady ? 1 : 0, diag.upgradeReason || '', JSON.stringify(diag.warnings || []), parsed.nextStep?.action || '', parsed.nextStep?.strategy || '', JSON.stringify(diag.knowledgeIds || []), now);
        // Set as active diagnosis
        db_1.default.prepare('UPDATE chat_targets SET active_diagnosis_id = ? WHERE id = ?').run(diagId, target.id);
        // Accumulate warnings
        for (const w of (diag.warnings || [])) {
            let wt = 'other';
            if (/诚意陷阱|诚意/.test(w))
                wt = 'sincerity_trap';
            else if (/真命天女|迷恋/.test(w))
                wt = 'oneitis';
            else if (/因果链|放大/.test(w))
                wt = 'causal_chain';
            else if (/越级|操之过急/.test(w))
                wt = 'over_escalation';
            else if (/需求感|暴露/.test(w))
                wt = 'neediness';
            const existing = db_1.default.prepare('SELECT id, count FROM user_warnings WHERE user_id = ? AND target_id = ? AND warning_type = ?').get(req.user.userId, target.id, wt);
            if (existing) {
                db_1.default.prepare('UPDATE user_warnings SET count = count + 1, detail = ?, updated_at = ? WHERE id = ?').run(w, now, existing.id);
            }
            else {
                db_1.default.prepare('INSERT INTO user_warnings (id, user_id, target_id, warning_type, detail, count, updated_at) VALUES (?, ?, ?, ?, ?, 1, ?)').run((0, uuid_1.v4)(), req.user.userId, target.id, wt, w, now);
            }
        }
        const diagnosis = {
            id: diagId, target_id: target.id,
            attitude_level: parsed.attitude?.level || '',
            language_pattern: parsed.attitude?.languagePattern || '',
            emotion_type: parsed.emotion?.type || '',
            emotion_valence: parsed.emotion?.valence || '',
            stage: diag.stage || '',
            upgrade_ready: !!diag.upgradeReady,
            upgrade_reason: diag.upgradeReason || '',
            warnings: diag.warnings || [],
            action: parsed.nextStep?.action || '',
            strategy: parsed.nextStep?.strategy || '',
            knowledgeIds: diag.knowledgeIds || [],
            created_at: now,
        };
        send('diagnosis_done', { diagnosis });
        res.end();
    }
    catch (err) {
        console.error('Diagnose error:', err);
        try {
            res.write(`event: error\ndata: ${JSON.stringify({ message: err.message || '诊断服务异常' })}\n\n`);
            res.end();
        }
        catch { /* connection already closed */ }
    }
});
// GET /api/targets/:targetId/active-diagnosis
app.get('/api/targets/:targetId/active-diagnosis', (req, res) => {
    const target = db_1.default.prepare('SELECT * FROM chat_targets WHERE id = ? AND user_id = ?').get(req.params.targetId, req.user.userId);
    if (!target) {
        res.status(404).json({ error: '聊天对象不存在' });
        return;
    }
    if (!target.active_diagnosis_id) {
        res.json({ diagnosis: null });
        return;
    }
    const d = db_1.default.prepare('SELECT * FROM chat_diagnoses WHERE id = ?').get(target.active_diagnosis_id);
    if (!d) {
        res.json({ diagnosis: null });
        return;
    }
    res.json({
        diagnosis: {
            id: d.id, target_id: d.target_id,
            attitude_level: d.attitude_level,
            language_pattern: d.language_pattern,
            emotion_type: d.emotion_type,
            emotion_valence: d.emotion_valence,
            stage: d.stage,
            upgrade_ready: !!d.upgrade_ready,
            upgrade_reason: d.upgrade_reason,
            warnings: JSON.parse(d.warnings_json || '[]'),
            action: d.action,
            strategy: d.strategy,
            knowledgeIds: JSON.parse(d.knowledge_ids || '[]'),
            created_at: d.created_at,
        },
    });
});
// DELETE /api/targets/:targetId/active-diagnosis
app.delete('/api/targets/:targetId/active-diagnosis', (req, res) => {
    const target = db_1.default.prepare('SELECT * FROM chat_targets WHERE id = ? AND user_id = ?').get(req.params.targetId, req.user.userId);
    if (!target) {
        res.status(404).json({ error: '聊天对象不存在' });
        return;
    }
    db_1.default.prepare('UPDATE chat_targets SET active_diagnosis_id = NULL WHERE id = ?').run(target.id);
    res.json({ success: true });
});
// ===== Internal helper: run diagnosis (non-SSE, used by generate/regenerate) =====
async function runDiagnosisInternal(target, recentMessages, provider) {
    const systemPrompt = (0, prompt_1.buildAdvisorPrompt)({ target, recentMessages, contextSummary: '' });
    const messages = [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: '请分析对方当前的状态' },
    ];
    const raw = await (0, llm_1.chatCompletion)(messages, provider, 16384);
    let parsed = parseJsonSafely(raw);
    if (!parsed) {
        console.error('[Auto-Diagnose Parse Error] Full raw output:\n', raw);
        throw new Error('自动诊断解析失败');
    }
    // Validate: must have attitude or at minimum some structure
    if (!parsed.attitude?.level || !parsed.emotion?.type) {
        console.error('[Auto-Diagnose Invalid] Unexpected structure:', JSON.stringify(parsed).slice(0, 500));
        // Graceful degradation instead of throwing
        parsed = {
            ...parsed,
            attitude: parsed.attitude || {},
            emotion: parsed.emotion || {},
            diagnosis: parsed.diagnosis || {},
            nextStep: parsed.nextStep || {},
        };
        parsed.attitude.level = parsed.attitude.level || '回应';
        parsed.attitude.languagePattern = parsed.attitude.languagePattern || '无法判断';
        parsed.attitude.detail = parsed.attitude.detail || '数据不足以做出准确判断';
        parsed.attitude.evidence = parsed.attitude.evidence || '';
        parsed.emotion.type = parsed.emotion.type || '未知';
        parsed.emotion.valence = parsed.emotion.valence || '中性';
        parsed.emotion.detail = parsed.emotion.detail || '情绪状态不明确';
        parsed.emotion.evidence = parsed.emotion.evidence || '';
        console.log('[Auto-Diagnose] Using degraded fallback structure');
    }
    const diag = parsed.diagnosis || {};
    const diagId = (0, uuid_1.v4)();
    const now = Date.now();
    db_1.default.prepare(`INSERT INTO chat_diagnoses (id, session_id, target_id, attitude_level, language_pattern, emotion_type, emotion_valence, stage, upgrade_ready, upgrade_reason, warnings_json, action, strategy, knowledge_ids, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
        .run(diagId, '', target.id, parsed.attitude?.level || '', parsed.attitude?.languagePattern || '', parsed.emotion?.type || '', parsed.emotion?.valence || '', diag.stage || '', diag.upgradeReady ? 1 : 0, diag.upgradeReason || '', JSON.stringify(diag.warnings || []), parsed.nextStep?.action || '', parsed.nextStep?.strategy || '', JSON.stringify(diag.knowledgeIds || []), now);
    db_1.default.prepare('UPDATE chat_targets SET active_diagnosis_id = ? WHERE id = ?').run(diagId, target.id);
    // Accumulate warnings
    for (const w of (diag.warnings || [])) {
        let wt = 'other';
        if (/诚意陷阱|诚意/.test(w))
            wt = 'sincerity_trap';
        else if (/真命天女|迷恋/.test(w))
            wt = 'oneitis';
        else if (/因果链|放大/.test(w))
            wt = 'causal_chain';
        else if (/越级|操之过急/.test(w))
            wt = 'over_escalation';
        else if (/需求感|暴露/.test(w))
            wt = 'neediness';
        const existing = db_1.default.prepare('SELECT id, count FROM user_warnings WHERE user_id = ? AND target_id = ? AND warning_type = ?').get(target.user_id, target.id, wt);
        if (existing) {
            db_1.default.prepare('UPDATE user_warnings SET count = count + 1, detail = ?, updated_at = ? WHERE id = ?').run(w, now, existing.id);
        }
        else {
            db_1.default.prepare('INSERT INTO user_warnings (id, user_id, target_id, warning_type, detail, count, updated_at) VALUES (?, ?, ?, ?, ?, 1, ?)').run((0, uuid_1.v4)(), target.user_id, target.id, wt, w, now);
        }
    }
    return {
        id: diagId, target_id: target.id,
        attitude_level: parsed.attitude?.level || '',
        language_pattern: parsed.attitude?.languagePattern || '',
        emotion_type: parsed.emotion?.type || '',
        emotion_valence: parsed.emotion?.valence || '',
        stage: diag.stage || '',
        upgrade_ready: !!diag.upgradeReady,
        upgrade_reason: diag.upgradeReason || '',
        warnings: diag.warnings || [],
        action: parsed.nextStep?.action || '',
        strategy: parsed.nextStep?.strategy || '',
        knowledgeIds: diag.knowledgeIds || [],
        created_at: now,
    };
}
// ===== Advisor Analysis & Review Summary =====
app.post('/api/sessions/:sessionId/analyze', async (req, res) => {
    try {
        const { mode, provider } = req.body;
        if (mode !== 'advisor' && mode !== 'review') {
            res.status(400).json({ error: '无效的分析模式' });
            return;
        }
        const session = db_1.default.prepare('SELECT * FROM ai_sessions WHERE id = ?').get(req.params.sessionId);
        if (!session || !verifyTargetOwnership(session.target_id, req.user.userId)) {
            res.status(404).json({ error: '辅导窗口不存在' });
            return;
        }
        const target = db_1.default.prepare('SELECT * FROM chat_targets WHERE id = ?').get(session.target_id);
        if (!target) {
            res.status(404).json({ error: '聊天对象不存在' });
            return;
        }
        const recentMessages = db_1.default.prepare('SELECT * FROM chat_messages WHERE target_id = ? ORDER BY created_at DESC LIMIT 30').all(target.id).reverse();
        if (recentMessages.length < 2) {
            res.status(400).json({ error: '聊天记录太少，至少需要2条消息才能分析' });
            return;
        }
        // SSE headers
        res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', 'Connection': 'keep-alive' });
        let clientDisconnected = false;
        req.on('close', () => { clientDisconnected = true; });
        const send = (event, data) => { if (!clientDisconnected) {
            try {
                res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);
            }
            catch { }
        } };
        send('step', { step: 'analyzing' });
        // Build prompt based on mode
        let systemPrompt;
        if (mode === 'advisor') {
            systemPrompt = (0, prompt_1.buildAdvisorPrompt)({ target, recentMessages: recentMessages, contextSummary: session.context_summary || '' });
        }
        else {
            const selections = db_1.default.prepare('SELECT reply_text, strategy FROM reply_selections WHERE session_id = ? ORDER BY created_at ASC').all(session.id);
            systemPrompt = (0, prompt_1.buildReviewPrompt)({ target, recentMessages: recentMessages, replySelections: selections || [] });
        }
        const conversationMessages = [
            { role: 'system', content: systemPrompt },
            { role: 'user', content: mode === 'advisor' ? '请分析对方当前的状态' : '请复盘我的聊天表现' },
        ];
        // Stream LLM response
        let raw = '';
        const heartbeatTimer = setInterval(() => { send('heartbeat', { ts: Date.now() }); }, 2000);
        try {
            for await (const delta of (0, llm_1.chatCompletionStream)(conversationMessages, provider || 'zhipu', 1, 16384)) {
                raw += delta;
                if (clientDisconnected)
                    break;
                send('delta', { text: delta });
            }
        }
        finally {
            clearInterval(heartbeatTimer);
        }
        // Parse response
        send('step', { step: 'parsing' });
        let parsed = parseJsonSafely(raw);
        if (!parsed) {
            console.error('[Analyze Parse Error] Full raw output:\n', raw);
            send('debug_raw', { source: mode, rawLength: raw.length, rawPreview: raw.slice(0, 800) });
            // Create fallback response based on mode instead of erroring
            if (mode === 'advisor') {
                parsed = {
                    attitude: { level: '无法判断', languagePattern: '解析异常', detail: 'AI 返回格式异常，建议重试', evidence: '' },
                    emotion: { type: '未知', valence: '中性', detail: '无法识别', evidence: '' },
                    thought: { intention: '数据不足（低）', expectation: '无法判断', detail: '本次分析结果未能解析，请重新分析' },
                    diagnosis: { warnings: ['解析失败，请重试'], stage: '信息不足', upgradeReady: false, upgradeReason: '', knowledgeIds: [] },
                    nextStep: { action: '建议重新分析', strategy: '重试', keyPoints: [], warnings: ['请重试'] },
                };
            }
            else {
                parsed = {
                    highlights: [],
                    mistakes: [],
                    scores: { signalRecognition: 3, strategySelection: 3, rhythmControl: 3, emotionManagement: 3, responseQuality: 3 },
                    overall: { total: 60, summary: 'AI 返回格式异常，分数为降级默认值，建议重新复盘', strengths: [], weaknesses: ['解析失败'], advice: '请重新点击复盘', warningLevel: 'yellow', knowledgeGaps: [] },
                };
            }
        }
        // Save to ai_messages
        const aiMsgId = (0, uuid_1.v4)();
        db_1.default.prepare('INSERT INTO ai_messages (id, session_id, role, content, round_id, version, msg_type, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)')
            .run(aiMsgId, session.id, 'assistant', JSON.stringify(parsed), null, 1, mode, Date.now());
        // ===== 自动存储到评估/诊断/警告表 =====
        if (mode === 'advisor' && parsed.diagnosis) {
            const diag = parsed.diagnosis;
            db_1.default.prepare(`INSERT INTO chat_diagnoses (id, session_id, target_id, attitude_level, language_pattern, emotion_type, emotion_valence, stage, upgrade_ready, upgrade_reason, warnings_json, action, strategy, knowledge_ids, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
                .run((0, uuid_1.v4)(), session.id, target.id, parsed.attitude?.level || '', parsed.attitude?.languagePattern || '', parsed.emotion?.type || '', parsed.emotion?.valence || '', diag.stage || '', diag.upgradeReady ? 1 : 0, diag.upgradeReason || '', JSON.stringify(diag.warnings || []), parsed.nextStep?.action || '', parsed.nextStep?.strategy || '', JSON.stringify(diag.knowledgeIds || []), Date.now());
            // 累积警告
            for (const w of (diag.warnings || [])) {
                let wt = 'other';
                if (/诚意陷阱|诚意/.test(w))
                    wt = 'sincerity_trap';
                else if (/真命天女|迷恋/.test(w))
                    wt = 'oneitis';
                else if (/因果链|放大/.test(w))
                    wt = 'causal_chain';
                else if (/越级|操之过急/.test(w))
                    wt = 'over_escalation';
                else if (/需求感|暴露/.test(w))
                    wt = 'neediness';
                const existing = db_1.default.prepare('SELECT id, count FROM user_warnings WHERE user_id = ? AND target_id = ? AND warning_type = ?').get(req.user.userId, target.id, wt);
                if (existing) {
                    db_1.default.prepare('UPDATE user_warnings SET count = count + 1, detail = ?, updated_at = ? WHERE id = ?').run(w, Date.now(), existing.id);
                }
                else {
                    db_1.default.prepare('INSERT INTO user_warnings (id, user_id, target_id, warning_type, detail, count, updated_at) VALUES (?, ?, ?, ?, ?, 1, ?)').run((0, uuid_1.v4)(), req.user.userId, target.id, wt, w, Date.now());
                }
            }
        }
        if (mode === 'review' && parsed.scores) {
            const ov = parsed.overall || {};
            db_1.default.prepare(`INSERT INTO chat_evaluations (id, session_id, target_id, scores_json, total_score, warning_level, highlights_json, mistakes_json, strengths, weaknesses, advice, knowledge_gaps, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
                .run((0, uuid_1.v4)(), session.id, target.id, JSON.stringify(parsed.scores), ov.total || 0, ov.warningLevel || 'green', JSON.stringify(parsed.highlights || []), JSON.stringify(parsed.mistakes || []), JSON.stringify(ov.strengths || []), JSON.stringify(ov.weaknesses || []), ov.advice || '', JSON.stringify(ov.knowledgeGaps || []), Date.now());
        }
        send('analysis_done', { result: parsed, aiMessageId: aiMsgId });
        res.end();
    }
    catch (err) {
        console.error('Analyze error:', err);
        try {
            res.write(`event: error\ndata: ${JSON.stringify({ message: err.message || '分析服务异常' })}\n\n`);
            res.end();
        }
        catch { }
    }
});
// ===== Get Analysis History by Target =====
app.get('/api/targets/:targetId/analyses', (req, res) => {
    const { type } = req.query;
    const target = db_1.default.prepare('SELECT * FROM chat_targets WHERE id = ?').get(req.params.targetId);
    if (!target || target.user_id !== req.user.userId) {
        res.status(404).json({ error: '聊天对象不存在' });
        return;
    }
    const sessionIds = db_1.default.prepare('SELECT id FROM ai_sessions WHERE target_id = ?').all(req.params.targetId).map((s) => s.id);
    if (sessionIds.length === 0) {
        res.json([]);
        return;
    }
    const placeholders = sessionIds.map(() => '?').join(',');
    let query = `SELECT id, msg_type, content, created_at FROM ai_messages WHERE session_id IN (${placeholders}) AND msg_type IN ('advisor', 'review')`;
    const params = [...sessionIds];
    if (type === 'advisor' || type === 'review') {
        query += ' AND msg_type = ?';
        params.push(type);
    }
    query += ' ORDER BY created_at DESC LIMIT 50';
    res.json(db_1.default.prepare(query).all(...params));
});
// ===== 评估记录查询 =====
app.get('/api/targets/:targetId/evaluations', (req, res) => {
    const target = db_1.default.prepare('SELECT * FROM chat_targets WHERE id = ?').get(req.params.targetId);
    if (!target || target.user_id !== req.user.userId) {
        res.status(404).json({ error: '聊天对象不存在' });
        return;
    }
    const rows = db_1.default.prepare('SELECT * FROM chat_evaluations WHERE target_id = ? ORDER BY created_at DESC LIMIT 20').all(req.params.targetId);
    res.json(rows.map(e => ({
        ...e, scores: JSON.parse(e.scores_json), highlights: JSON.parse(e.highlights_json),
        mistakes: JSON.parse(e.mistakes_json), strengths: JSON.parse(e.strengths),
        weaknesses: JSON.parse(e.weaknesses), knowledgeGaps: JSON.parse(e.knowledge_gaps),
        scores_json: undefined, highlights_json: undefined, mistakes_json: undefined, knowledge_gaps: undefined,
    })));
});
// ===== 诊断记录查询 =====
app.get('/api/targets/:targetId/diagnoses', (req, res) => {
    const target = db_1.default.prepare('SELECT * FROM chat_targets WHERE id = ?').get(req.params.targetId);
    if (!target || target.user_id !== req.user.userId) {
        res.status(404).json({ error: '聊天对象不存在' });
        return;
    }
    const rows = db_1.default.prepare('SELECT * FROM chat_diagnoses WHERE target_id = ? ORDER BY created_at DESC LIMIT 20').all(req.params.targetId);
    res.json(rows.map(d => ({
        ...d, warnings: JSON.parse(d.warnings_json), knowledgeIds: JSON.parse(d.knowledge_ids),
        warnings_json: undefined, knowledge_ids: undefined,
    })));
});
// ===== 累积警告查询 =====
app.get('/api/targets/:targetId/warnings', (req, res) => {
    const target = db_1.default.prepare('SELECT * FROM chat_targets WHERE id = ?').get(req.params.targetId);
    if (!target || target.user_id !== req.user.userId) {
        res.status(404).json({ error: '聊天对象不存在' });
        return;
    }
    res.json(db_1.default.prepare('SELECT * FROM user_warnings WHERE user_id = ? AND target_id = ? ORDER BY updated_at DESC').all(req.user.userId, req.params.targetId));
});
app.post('/api/sessions/:sessionId/feedback', (req, res) => {
    const { replyId, rating } = req.body;
    const session = db_1.default.prepare('SELECT * FROM ai_sessions WHERE id = ?').get(req.params.sessionId);
    if (!session || !verifyTargetOwnership(session.target_id, req.user.userId)) {
        res.status(404).json({ error: '辅导窗口不存在' });
        return;
    }
    db_1.default.prepare('INSERT INTO ai_messages (id, session_id, role, content, created_at) VALUES (?, ?, ?, ?, ?)')
        .run((0, uuid_1.v4)(), req.params.sessionId, 'user', JSON.stringify({ type: 'feedback', replyId, rating }), Date.now());
    res.json({ success: true });
});
// ===== Admin Middleware =====
function adminMiddleware(req, res, next) {
    const user = db_1.default.prepare('SELECT role FROM users WHERE id = ?').get(req.user.userId);
    if (!user || user.role !== 'admin') {
        res.status(403).json({ error: '需要管理员权限' });
        return;
    }
    next();
}
// ===== Admin API Routes =====
// Check if current user is admin
app.get('/api/admin/me', authMiddleware, (req, res) => {
    const user = db_1.default.prepare('SELECT role FROM users WHERE id = ?').get(req.user.userId);
    res.json({ isAdmin: user?.role === 'admin' });
});
// System statistics
app.get('/api/admin/stats', authMiddleware, adminMiddleware, (_req, res) => {
    const users = db_1.default.prepare('SELECT COUNT(*) as count FROM users').get().count;
    const targets = db_1.default.prepare('SELECT COUNT(*) as count FROM chat_targets').get().count;
    const messages = db_1.default.prepare('SELECT COUNT(*) as count FROM chat_messages').get().count;
    const sessions = db_1.default.prepare('SELECT COUNT(*) as count FROM ai_sessions').get().count;
    const diagnoses = db_1.default.prepare('SELECT COUNT(*) as count FROM chat_diagnoses').get().count;
    const evaluations = db_1.default.prepare('SELECT COUNT(*) as count FROM chat_evaluations').get().count;
    // Recent activity (last 24h)
    const oneDayAgo = Date.now() - 24 * 60 * 60 * 1000;
    const recentMessages = db_1.default.prepare('SELECT COUNT(*) as count FROM chat_messages WHERE created_at > ?').get(oneDayAgo).count;
    const recentSessions = db_1.default.prepare('SELECT COUNT(*) as count FROM ai_sessions WHERE created_at > ?').get(oneDayAgo).count;
    // Database file size
    let dbSizeKB = 0;
    try {
        const fsSync = require('fs');
        const pathSync = require('path');
        const stat = fsSync.statSync(pathSync.join(process.cwd(), 'data', 'chat-trainer.db'));
        dbSizeKB = Math.round(stat.size / 1024);
    }
    catch { }
    res.json({
        users, targets, messages, sessions, diagnoses, evaluations,
        recentMessages, recentSessions, dbSizeKB,
    });
});
// List all users with usage stats
app.get('/api/admin/users', authMiddleware, adminMiddleware, (_req, res) => {
    const users = db_1.default.prepare('SELECT id, username, role, created_at FROM users ORDER BY created_at ASC').all();
    const usersWithStats = users.map(u => {
        const targetCount = db_1.default.prepare('SELECT COUNT(*) as count FROM chat_targets WHERE user_id = ?').get(u.id).count;
        const messageCount = db_1.default.prepare('SELECT COUNT(*) as count FROM chat_messages WHERE target_id IN (SELECT id FROM chat_targets WHERE user_id = ?)').get(u.id).count;
        const sessionCount = db_1.default.prepare('SELECT COUNT(*) as count FROM ai_sessions WHERE target_id IN (SELECT id FROM chat_targets WHERE user_id = ?)').get(u.id).count;
        return { ...u, targetCount, messageCount, sessionCount };
    });
    res.json(usersWithStats);
});
// Delete a user and all their data
app.delete('/api/admin/users/:id', authMiddleware, adminMiddleware, (req, res) => {
    const userId = req.params.id;
    const user = db_1.default.prepare('SELECT * FROM users WHERE id = ?').get(userId);
    if (!user) {
        res.status(404).json({ error: '用户不存在' });
        return;
    }
    if (user.role === 'admin') {
        res.status(400).json({ error: '不能删除管理员账户' });
        return;
    }
    db_1.default.transaction(() => {
        const targetIds = db_1.default.prepare('SELECT id FROM chat_targets WHERE user_id = ?').all(userId).map((t) => t.id);
        for (const targetId of targetIds) {
            const sessionIds = db_1.default.prepare('SELECT id FROM ai_sessions WHERE target_id = ?').all(targetId).map((s) => s.id);
            for (const sessionId of sessionIds) {
                db_1.default.prepare('DELETE FROM ai_messages WHERE session_id = ?').run(sessionId);
                db_1.default.prepare('DELETE FROM reply_selections WHERE session_id = ?').run(sessionId);
            }
            db_1.default.prepare('DELETE FROM ai_sessions WHERE target_id = ?').run(targetId);
            db_1.default.prepare('DELETE FROM chat_messages WHERE target_id = ?').run(targetId);
            db_1.default.prepare('DELETE FROM chat_diagnoses WHERE target_id = ?').run(targetId);
            db_1.default.prepare('DELETE FROM chat_evaluations WHERE target_id = ?').run(targetId);
            db_1.default.prepare('DELETE FROM user_warnings WHERE target_id = ?').run(targetId);
        }
        db_1.default.prepare('DELETE FROM chat_targets WHERE user_id = ?').run(userId);
        db_1.default.prepare('DELETE FROM users WHERE id = ?').run(userId);
    })();
    res.json({ success: true });
});
// Change user role
app.put('/api/admin/users/:id/role', authMiddleware, adminMiddleware, (req, res) => {
    const { role } = req.body;
    if (!['admin', 'user'].includes(role)) {
        res.status(400).json({ error: '无效角色' });
        return;
    }
    const user = db_1.default.prepare('SELECT * FROM users WHERE id = ?').get(req.params.id);
    if (!user) {
        res.status(404).json({ error: '用户不存在' });
        return;
    }
    db_1.default.prepare('UPDATE users SET role = ? WHERE id = ?').run(role, req.params.id);
    res.json({ success: true });
});
// Get system settings
app.get('/api/admin/settings', authMiddleware, adminMiddleware, (_req, res) => {
    const rows = db_1.default.prepare('SELECT key, value FROM system_settings').all();
    const settings = {};
    for (const row of rows) {
        settings[row.key] = row.value;
    }
    res.json(settings);
});
// Update system settings
app.put('/api/admin/settings', authMiddleware, adminMiddleware, (req, res) => {
    const allowedKeys = ['allow_registration', 'max_targets_per_user', 'max_sessions_per_target'];
    for (const [key, value] of Object.entries(req.body)) {
        if (allowedKeys.includes(key)) {
            db_1.default.prepare('INSERT OR REPLACE INTO system_settings (key, value, updated_at) VALUES (?, ?, ?)').run(key, String(value), Date.now());
        }
    }
    res.json({ success: true });
});
app.listen(PORT, async () => {
    await (0, db_1.initDb)();
    console.log(`Server running on http://localhost:${PORT}`);
});
exports.default = app;
