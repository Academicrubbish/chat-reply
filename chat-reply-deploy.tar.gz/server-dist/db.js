"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.initDb = initDb;
exports.hashPassword = hashPassword;
exports.verifyPassword = verifyPassword;
const sql_js_1 = __importDefault(require("sql.js"));
const path_1 = __importDefault(require("path"));
const fs_1 = __importDefault(require("fs"));
const bcryptjs_1 = __importDefault(require("bcryptjs"));
const dataDir = path_1.default.join(process.cwd(), 'data');
if (!fs_1.default.existsSync(dataDir)) {
    fs_1.default.mkdirSync(dataDir, { recursive: true });
}
const dbPath = path_1.default.join(dataDir, 'chat-trainer.db');
let db;
let inTransaction = false;
function saveDb() {
    if (inTransaction)
        return;
    const data = db.export();
    const buffer = Buffer.from(data);
    fs_1.default.writeFileSync(dbPath, buffer);
}
function runStatement(sql, params) {
    try {
        if (params && params.length > 0) {
            db.run(sql, params);
        }
        else {
            db.run(sql);
        }
        saveDb();
    }
    catch (e) {
        if (!sql.startsWith('CREATE') && !sql.startsWith('CREATE INDEX')) {
            throw e;
        }
    }
}
function bindParams(stmt, params) {
    if (params.length > 0)
        stmt.bind(params);
}
function prepareStmt(sql) {
    return {
        run(...params) {
            const stmt = db.prepare(sql);
            bindParams(stmt, params);
            if (sql.trim().toUpperCase().startsWith('SELECT')) {
                stmt.step();
            }
            else {
                stmt.step();
            }
            const changes = db.getRowsModified();
            stmt.free();
            saveDb();
            return { lastInsertRowid: 0, changes };
        },
        get(...params) {
            const stmt = db.prepare(sql);
            bindParams(stmt, params);
            const hasRow = stmt.step();
            let result;
            if (hasRow) {
                result = stmt.getAsObject();
            }
            stmt.free();
            return result;
        },
        all(...params) {
            const stmt = db.prepare(sql);
            bindParams(stmt, params);
            const results = [];
            while (stmt.step()) {
                results.push(stmt.getAsObject());
            }
            stmt.free();
            return results;
        },
    };
}
const dbWrapper = {
    prepare(sql) {
        return prepareStmt(sql);
    },
    exec(sql) {
        const statements = sql
            .split(';')
            .map(s => s.trim())
            .filter(s => s.length > 0);
        for (const stmt of statements) {
            runStatement(stmt);
        }
        saveDb();
    },
    pragma(pragma) {
        db.run(`PRAGMA ${pragma}`);
        saveDb();
    },
    transaction(fn) {
        return (...args) => {
            inTransaction = true;
            db.run('BEGIN');
            try {
                const result = fn(...args);
                db.run('COMMIT');
                inTransaction = false;
                saveDb();
                return result;
            }
            catch (e) {
                try {
                    db.run('ROLLBACK');
                }
                catch { }
                inTransaction = false;
                saveDb();
                throw e;
            }
        };
    },
};
const initSqlJsModule = (0, sql_js_1.default)();
let dbBuffer;
if (fs_1.default.existsSync(dbPath)) {
    dbBuffer = fs_1.default.readFileSync(dbPath);
}
let dbReady = false;
async function initDb() {
    if (dbReady)
        return;
    const SQL = await initSqlJsModule;
    if (dbBuffer) {
        db = new SQL.Database(dbBuffer);
    }
    else {
        db = new SQL.Database();
    }
    dbWrapper.pragma('journal_mode = WAL');
    dbWrapper.pragma('foreign_keys = ON');
    dbWrapper.exec(`
    CREATE TABLE IF NOT EXISTS chat_targets (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      name TEXT NOT NULL,
      meet_scene TEXT DEFAULT '',
      persona TEXT DEFAULT '',
      hobbies TEXT DEFAULT '',
      recent_chats TEXT DEFAULT '',
      tone_level TEXT DEFAULT 'moderate',
      goal_intent TEXT DEFAULT 'pursuing',
      forbidden_topics TEXT DEFAULT '',
      created_at INTEGER NOT NULL,
      FOREIGN KEY (user_id) REFERENCES users(id)
    );


    CREATE TABLE IF NOT EXISTS chat_messages (
      id TEXT PRIMARY KEY,
      target_id TEXT NOT NULL,
      role TEXT NOT NULL,
      text TEXT NOT NULL,
      source TEXT NOT NULL,
      strategy TEXT DEFAULT NULL,
      session_id TEXT DEFAULT NULL,
      created_at INTEGER NOT NULL,
      FOREIGN KEY (target_id) REFERENCES chat_targets(id)
    );

    CREATE INDEX IF NOT EXISTS idx_messages_target ON chat_messages(target_id, created_at);

    CREATE TABLE IF NOT EXISTS ai_sessions (
      id TEXT PRIMARY KEY,
      target_id TEXT NOT NULL,
      title TEXT NOT NULL,
      is_active INTEGER DEFAULT 1,
      round_count INTEGER DEFAULT 0,
      context_tokens INTEGER DEFAULT 0,
      plan_goal TEXT DEFAULT '',
      plan_next_step TEXT DEFAULT '',
      created_at INTEGER NOT NULL,
      FOREIGN KEY (target_id) REFERENCES chat_targets(id)
    );

    CREATE TABLE IF NOT EXISTS ai_messages (
      id TEXT PRIMARY KEY,
      session_id TEXT NOT NULL,
      role TEXT NOT NULL,
      content TEXT NOT NULL,
      round_id TEXT DEFAULT NULL,
      version INTEGER DEFAULT 1,
      created_at INTEGER NOT NULL,
      FOREIGN KEY (session_id) REFERENCES ai_sessions(id)
    );

    CREATE INDEX IF NOT EXISTS idx_ai_messages_session ON ai_messages(session_id, created_at);
    CREATE INDEX IF NOT EXISTS idx_ai_messages_round ON ai_messages(session_id, round_id, version);

    CREATE TABLE IF NOT EXISTS reply_selections (
      id TEXT PRIMARY KEY,
      session_id TEXT NOT NULL,
      ai_message_id TEXT NOT NULL,
      reply_id INTEGER NOT NULL,
      reply_text TEXT NOT NULL,
      strategy TEXT,
      chat_message_id TEXT NOT NULL,
      created_at INTEGER NOT NULL,
      FOREIGN KEY (session_id) REFERENCES ai_sessions(id),
      FOREIGN KEY (ai_message_id) REFERENCES ai_messages(id),
      FOREIGN KEY (chat_message_id) REFERENCES chat_messages(id)
    );

    CREATE INDEX IF NOT EXISTS idx_reply_selections_session ON reply_selections(session_id);
    CREATE INDEX IF NOT EXISTS idx_reply_selections_ai_msg ON reply_selections(ai_message_id);

    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      username TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      created_at INTEGER NOT NULL
    );
  `);
    // Migrate existing databases: add user_id to chat_targets if missing
    try {
        dbWrapper.exec(`ALTER TABLE chat_targets ADD COLUMN user_id TEXT NOT NULL DEFAULT ''`);
    }
    catch { }
    // Migrate: add round_id and version to ai_messages if missing
    try {
        dbWrapper.exec(`ALTER TABLE ai_messages ADD COLUMN round_id TEXT DEFAULT NULL`);
    }
    catch { }
    try {
        dbWrapper.exec(`ALTER TABLE ai_messages ADD COLUMN version INTEGER DEFAULT 1`);
    }
    catch { }
    // Migrate: add context_summary to ai_sessions if missing
    try {
        dbWrapper.exec(`ALTER TABLE ai_sessions ADD COLUMN context_summary TEXT DEFAULT ''`);
    }
    catch { }
    // Migrate: add msg_type to ai_messages for advisor/review analysis
    try {
        dbWrapper.exec(`ALTER TABLE ai_messages ADD COLUMN msg_type TEXT DEFAULT 'reply'`);
    }
    catch { }
    try {
        dbWrapper.exec(`CREATE INDEX IF NOT EXISTS idx_ai_messages_type ON ai_messages(session_id, msg_type)`);
    }
    catch { }
    // ===== 新增：评估/诊断/警告表 =====
    dbWrapper.exec(`
    CREATE TABLE IF NOT EXISTS chat_evaluations (
      id TEXT PRIMARY KEY,
      session_id TEXT NOT NULL,
      target_id TEXT NOT NULL,
      scores_json TEXT NOT NULL,
      total_score INTEGER NOT NULL,
      warning_level TEXT NOT NULL DEFAULT 'green',
      highlights_json TEXT NOT NULL,
      mistakes_json TEXT NOT NULL,
      strengths TEXT DEFAULT '',
      weaknesses TEXT DEFAULT '',
      advice TEXT DEFAULT '',
      knowledge_gaps TEXT DEFAULT '',
      created_at INTEGER NOT NULL,
      FOREIGN KEY (session_id) REFERENCES ai_sessions(id),
      FOREIGN KEY (target_id) REFERENCES chat_targets(id)
    );

    CREATE INDEX IF NOT EXISTS idx_evaluations_session ON chat_evaluations(session_id);
    CREATE INDEX IF NOT EXISTS idx_evaluations_target ON chat_evaluations(target_id, created_at);

    CREATE TABLE IF NOT EXISTS chat_diagnoses (
      id TEXT PRIMARY KEY,
      session_id TEXT DEFAULT NULL,
      target_id TEXT NOT NULL,
      attitude_level TEXT NOT NULL,
      language_pattern TEXT DEFAULT '',
      emotion_type TEXT DEFAULT '',
      emotion_valence TEXT DEFAULT '',
      stage TEXT DEFAULT '',
      upgrade_ready INTEGER DEFAULT 0,
      upgrade_reason TEXT DEFAULT '',
      warnings_json TEXT DEFAULT '[]',
      action TEXT DEFAULT '',
      strategy TEXT DEFAULT '',
      knowledge_ids TEXT DEFAULT '',
      created_at INTEGER NOT NULL,
      FOREIGN KEY (target_id) REFERENCES chat_targets(id)
    );

    CREATE INDEX IF NOT EXISTS idx_diagnoses_session ON chat_diagnoses(session_id);
    CREATE INDEX IF NOT EXISTS idx_diagnoses_target ON chat_diagnoses(target_id, created_at);

    CREATE TABLE IF NOT EXISTS user_warnings (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL,
      target_id TEXT NOT NULL,
      warning_type TEXT NOT NULL,
      detail TEXT DEFAULT '',
      count INTEGER DEFAULT 1,
      updated_at INTEGER NOT NULL,
      FOREIGN KEY (target_id) REFERENCES chat_targets(id)
    );

    CREATE INDEX IF NOT EXISTS idx_warnings_user_target ON user_warnings(user_id, target_id, warning_type);
  `);
    // Migrate: add active_diagnosis_id to chat_targets (diagnosis-first architecture)
    try {
        dbWrapper.exec(`ALTER TABLE chat_targets ADD COLUMN active_diagnosis_id TEXT DEFAULT NULL`);
    }
    catch { }
    // Migrate: add diagnosis_id to ai_sessions (track which diagnosis was used)
    try {
        dbWrapper.exec(`ALTER TABLE ai_sessions ADD COLUMN diagnosis_id TEXT DEFAULT NULL`);
    }
    catch { }
    // Migrate: add role to users (admin/user)
    try {
        dbWrapper.exec(`ALTER TABLE users ADD COLUMN role TEXT NOT NULL DEFAULT 'user'`);
        // First user becomes admin
        dbWrapper.exec(`UPDATE users SET role = 'admin' WHERE rowid = 1`);
    }
    catch { }
    // System settings table for admin configuration
    dbWrapper.exec(`
    CREATE TABLE IF NOT EXISTS system_settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL,
      updated_at INTEGER NOT NULL
    );
  `);
    // Initialize default settings
    const defaultSettings = [
        ['allow_registration', 'true'],
        ['max_targets_per_user', '50'],
        ['max_sessions_per_target', '20'],
    ];
    for (const [key, value] of defaultSettings) {
        const existing = dbWrapper.prepare('SELECT key FROM system_settings WHERE key = ?').get(key);
        if (!existing) {
            dbWrapper.prepare('INSERT INTO system_settings (key, value, updated_at) VALUES (?, ?, ?)').run(key, value, Date.now());
        }
    }
    // One-time: auto-activate the latest diagnosis for existing targets
    try {
        dbWrapper.exec(`
      UPDATE chat_targets SET active_diagnosis_id = (
        SELECT id FROM chat_diagnoses
        WHERE chat_diagnoses.target_id = chat_targets.id
        ORDER BY created_at DESC LIMIT 1
      ) WHERE active_diagnosis_id IS NULL
        AND EXISTS (SELECT 1 FROM chat_diagnoses WHERE chat_diagnoses.target_id = chat_targets.id)
    `);
    }
    catch { }
    // Migrate: make chat_diagnoses.session_id nullable, remove FK to ai_sessions
    try {
        dbWrapper.transaction(() => {
            dbWrapper.exec(`
        CREATE TABLE IF NOT EXISTS chat_diagnoses_new (
          id TEXT PRIMARY KEY,
          session_id TEXT DEFAULT NULL,
          target_id TEXT NOT NULL,
          attitude_level TEXT NOT NULL,
          language_pattern TEXT DEFAULT '',
          emotion_type TEXT DEFAULT '',
          emotion_valence TEXT DEFAULT '',
          stage TEXT DEFAULT '',
          upgrade_ready INTEGER DEFAULT 0,
          upgrade_reason TEXT DEFAULT '',
          warnings_json TEXT DEFAULT '[]',
          action TEXT DEFAULT '',
          strategy TEXT DEFAULT '',
          knowledge_ids TEXT DEFAULT '',
          created_at INTEGER NOT NULL,
          FOREIGN KEY (target_id) REFERENCES chat_targets(id)
        );
        INSERT INTO chat_diagnoses_new SELECT id, session_id, target_id, attitude_level, language_pattern, emotion_type, emotion_valence, stage, upgrade_ready, upgrade_reason, warnings_json, action, strategy, knowledge_ids, created_at FROM chat_diagnoses;
        DROP TABLE chat_diagnoses;
        ALTER TABLE chat_diagnoses_new RENAME TO chat_diagnoses;
      `);
            // Re-create indexes
            dbWrapper.exec(`
        CREATE INDEX IF NOT EXISTS idx_diagnoses_session ON chat_diagnoses(session_id);
        CREATE INDEX IF NOT EXISTS idx_diagnoses_target ON chat_diagnoses(target_id, created_at);
      `);
        })();
    }
    catch {
        // Already migrated or table doesn't exist yet — ignore
    }
    dbReady = true;
}
async function hashPassword(password) {
    return bcryptjs_1.default.hash(password, 10);
}
async function verifyPassword(password, hash) {
    return bcryptjs_1.default.compare(password, hash);
}
exports.default = dbWrapper;
