import type { ChatMessage } from './db';
interface PromptParams {
    target: {
        name: string;
        meet_scene: string;
        persona: string;
        hobbies: string;
        recent_chats: string;
        tone_level: string;
        goal_intent: string;
        forbidden_topics: string;
    };
    recentMessages: ChatMessage[];
    planGoal: string;
    planNextStep: string;
    feedbackPreferences: string;
    contextSummary?: string;
    diagnosis?: {
        stage: string;
        attitude_level: string;
        language_pattern: string;
        emotion_type: string;
        emotion_valence: string;
        upgrade_ready: boolean;
        upgrade_reason: string;
        warnings: string[];
        action: string;
        strategy: string;
        knowledgeIds: string[];
    } | null;
}
interface AdvisorPromptParams {
    target: {
        name: string;
        persona: string;
        hobbies: string;
        tone_level: string;
        goal_intent: string;
    };
    recentMessages: ChatMessage[];
    contextSummary?: string;
}
interface ReviewPromptParams {
    target: {
        name: string;
        persona: string;
        tone_level: string;
    };
    recentMessages: ChatMessage[];
    replySelections: Array<{
        reply_text: string;
        strategy: string | null;
    }>;
}
/** 获取 full mode 的静态前缀（角色定义 + 知识体系 + 红线），用于 API Prompt Caching */
export declare function getFullStaticPrefix(): string;
/** 获取 quick mode 的静态前缀（角色 + 精简知识 + 红线），用于 API Prompt Caching */
export declare function getQuickStaticPrefix(): string;
/** 构建按需注入版 full mode 的动态上下文 */
export declare function buildFullDynamicContextOptimized(params: PromptParams): string;
/** 按需注入版 full mode 静态前缀（角色 + 红线，不含知识） */
export declare function getFullStaticPrefixOptimized(): string;
/** 诊断驱动的回复生成 prompt（静态角色+红线 | 动态诊断+知识+上下文） */
export declare function buildFullMessagesOptimized(params: PromptParams): Array<{
    role: string;
    content: string;
}>;
export declare function buildSystemPrompt(params: PromptParams): string;
/** 构建动态上下文（每次请求变化的部分），作为第二条 system message */
export declare function buildFullDynamicContext(params: PromptParams): string;
/** 构建拆分版的 full mode messages 数组（静态 + 动态分离） */
export declare function buildFullMessages(params: PromptParams): Array<{
    role: string;
    content: string;
}>;
/** 构建拆分版的 quick mode messages 数组（静态 + 动态分离） */
export declare function buildQuickMessages(params: PromptParams): Array<{
    role: string;
    content: string;
}>;
export declare function buildQuickPrompt(params: PromptParams): string;
export declare function buildAdvisorPrompt(params: AdvisorPromptParams): string;
export declare function buildReviewPrompt(params: ReviewPromptParams): string;
export {};
