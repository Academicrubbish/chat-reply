export interface Stmt {
    run(...params: unknown[]): {
        lastInsertRowid: number | bigint;
        changes: number;
    };
    get(...params: unknown[]): Record<string, unknown> | undefined;
    all(...params: unknown[]): Record<string, unknown>[];
}
type TransactionFn = (...args: any[]) => any;
export interface DbWrapper {
    prepare(sql: string): Stmt;
    exec(sql: string): void;
    pragma(pragma: string): void;
    transaction<T extends TransactionFn>(fn: T): (...args: Parameters<T>) => ReturnType<T>;
}
declare const dbWrapper: DbWrapper;
export interface ChatMessage {
    id: string;
    target_id: string;
    role: string;
    text: string;
    source: string;
    strategy: string | null;
    session_id: string | null;
    created_at: number;
}
export declare function initDb(): Promise<void>;
export declare function hashPassword(password: string): Promise<string>;
export declare function verifyPassword(password: string, hash: string): Promise<boolean>;
export default dbWrapper;
