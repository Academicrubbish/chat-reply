"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getFullStaticPrefix = getFullStaticPrefix;
exports.getQuickStaticPrefix = getQuickStaticPrefix;
exports.buildFullDynamicContextOptimized = buildFullDynamicContextOptimized;
exports.getFullStaticPrefixOptimized = getFullStaticPrefixOptimized;
exports.buildFullMessagesOptimized = buildFullMessagesOptimized;
exports.buildSystemPrompt = buildSystemPrompt;
exports.buildFullDynamicContext = buildFullDynamicContext;
exports.buildFullMessages = buildFullMessages;
exports.buildQuickMessages = buildQuickMessages;
exports.buildQuickPrompt = buildQuickPrompt;
exports.buildAdvisorPrompt = buildAdvisorPrompt;
exports.buildReviewPrompt = buildReviewPrompt;
const knowledge_1 = require("./knowledge");
// ============ 静态 Prompt 缓存 ============
// 知识体系 + 红线在部署后不变，启动时预计算，避免每次请求重新格式化
const staticPromptCache = {};
function getCachedStaticPrompt(mode) {
    const key = `static_${mode}`;
    if (!staticPromptCache[key]) {
        const units = (0, knowledge_1.getUnitsForMode)(mode);
        if (mode === 'quick') {
            // Quick mode: 精简为查表格式
            const lines = ['## 快速参考'];
            for (const u of units) {
                lines.push(`**${u.id} ${u.title}**：${u.interpretation.split('\n')[0]}`);
                const trigger = u.triggers.find(t => t.modes.includes('quick'));
                if (trigger && trigger.languageSignals.length > 0) {
                    lines.push(`  信号：${trigger.languageSignals.join('、')}`);
                }
                if (u.execution.length > 0) {
                    lines.push(`  操作：${u.execution.slice(0, 2).map(s => s.action).join(' → ')}`);
                }
            }
            staticPromptCache[key] = lines.join('\n');
        }
        else {
            // Full mode: 完整知识体系
            staticPromptCache[key] = formatKnowledgeSection(units, mode);
        }
    }
    return staticPromptCache[key];
}
/** 获取 full mode 的静态前缀（角色定义 + 知识体系 + 红线），用于 API Prompt Caching */
function getFullStaticPrefix() {
    return `你是一个专业的社交聊天辅导AI，帮助用户分析对方消息并生成回复建议。你的核心方法论来自《魔鬼约会学》，严格按照以下知识体系运作。

# 知识体系

${getCachedStaticPrompt('full')}

# 红线禁忌

1. 对方明确拒绝时不得死缠烂打
2. 对方情绪不好（真生气/难过）时不使用扩大冲突
3. 不得生成涉及骚扰、强迫、不尊重的回复
4. 所有进攻型技巧的前提是对方的正面回应，没有正面回应就不能升级
5. 不要生成过于"油腻"或套路感过强的回复
6. 用表达自己来代替评价对方（安全法则）`;
}
/** 获取 quick mode 的静态前缀（角色 + 精简知识 + 红线），用于 API Prompt Caching */
function getQuickStaticPrefix() {
    return `你是社交聊天回复器。根据对方最新消息，快速生成3条回复。

${getCachedStaticPrompt('quick')}

## 红线
- 对方真生气→不用扩大冲突，改用共情
- 不生成油腻/套路感强的回复
- 遵守话题禁区`;
}
// ============ 知识按需注入 ============
/** 核心框架 ID — 无论消息内容如何，始终注入 */
const CORE_UNIT_IDS = new Set(['F01', 'F03']);
/** 根据对方最新消息，筛选最相关的知识单元 */
function selectRelevantUnits(allUnits, lastMessage, mode) {
    // 1. 始终包含核心框架
    const coreUnits = allUnits.filter(u => CORE_UNIT_IDS.has(u.id));
    // 2. 关键词匹配：遍历每个单元的 triggers.languageSignals
    const matchedUnits = allUnits.filter(u => {
        if (CORE_UNIT_IDS.has(u.id))
            return false; // 已在核心中
        return u.triggers.some(t => t.modes.includes(mode) &&
            t.languageSignals.some(signal => {
                // 模糊匹配：信号是消息的子串，或消息包含信号关键词
                if (signal.length <= 4) {
                    // 短信号（如"嗯"、"好的"）精确匹配
                    return lastMessage.includes(signal);
                }
                // 长信号提取关键词匹配
                const keywords = signal.replace(/[？?！!。，,、]/g, '').split(/\s+/).filter(w => w.length >= 2);
                return keywords.some(kw => lastMessage.includes(kw));
            }));
    });
    // 3. 合并去重
    const seen = new Set();
    const result = [];
    for (const u of [...coreUnits, ...matchedUnits]) {
        if (!seen.has(u.id)) {
            seen.add(u.id);
            result.push(u);
        }
    }
    // 4. 保底：如果匹配太少（<3个），从当前 mode 的单元中按优先级补充
    const modeUnits = allUnits.filter(u => u.modes.includes(mode) && !seen.has(u.id));
    const fallback = modeUnits
        .sort((a, b) => (b.priority || 3) - (a.priority || 3))
        .slice(0, Math.max(0, 3 - result.length));
    for (const u of fallback) {
        if (!seen.has(u.id)) {
            seen.add(u.id);
            result.push(u);
        }
    }
    return result;
}
/** 格式化按需筛选后的知识（full mode 使用） */
function formatSelectedKnowledge(units, mode) {
    return formatKnowledgeSection(units, mode);
}
/** 构建按需注入版 full mode 的动态上下文 */
function buildFullDynamicContextOptimized(params) {
    const { target, recentMessages, planGoal, planNextStep, feedbackPreferences } = params;
    const chatHistory = formatChatHistory(recentMessages);
    // 获取对方最新消息用于关键词匹配
    const lastHerMsg = [...recentMessages].reverse().find(m => m.role === 'her');
    const lastMessage = lastHerMsg?.text || '';
    // 按需选择知识单元
    const allUnits = (0, knowledge_1.getUnitsForMode)('full');
    const selectedUnits = selectRelevantUnits(allUnits, lastMessage, 'full');
    const knowledge = formatSelectedKnowledge(selectedUnits, 'full');
    console.log(`[Prompt] Selected ${selectedUnits.length}/${allUnits.length} knowledge units: ${selectedUnits.map(u => u.id).join(',')}`);
    const context = buildContextBlock(target, chatHistory, {
        '语气偏好': toneMapFull[target.tone_level] || '适中',
        '目标意图': goalMap[target.goal_intent] || '正在追求对方',
        '话题禁区': target.forbidden_topics || '无',
        '当前目标': planGoal || '探索阶段，建立舒适感',
        '下一步建议': planNextStep || '自然对话，寻找共同话题',
    });
    const feedback = feedbackPreferences ? `\n## 历史反馈偏好\n${feedbackPreferences}\n` : '';
    return `${context}
${feedback}# 输出要求

分析对方最新消息，返回JSON：
{"analysis":{"stage":"关系阶段（初期接触/聊天升温/暧昧期/约会恋爱期）","signal":"信号类型（正面冲突/正面无冲突/模糊/负面）","strategy":"推荐策略","signalText":"分析对方语气和隐含意思（2-3句）","emotions":["情绪标签1","情绪标签2"],"tip":"一句实用小建议","favorability":0-100,"favorabilityReason":"好感度判断依据（1-2句）","knowledgeIds":["用到的知识单元ID，如F01、F03"]},"plan":{"goal":"当前对话策略目标","nextStep":"下一步具体建议"},"replies":[{"id":1,"strategy":"策略名","text":"回复文本","reason":"推荐理由","knowledgeId":"对应的知识单元ID"}]}

要求：
- 生成3-4条回复，风格各异，至少1条安全回复
- 回复口语化自然，长度与对方发言匹配
- 每条标注策略名、理由和对应的知识单元ID
- 遵守语气偏好和话题禁区
- 基于历史反馈调整策略权重
- 只返回纯JSON，不要反引号markdown包裹，不要额外文字说明`;
}
/** 按需注入版 full mode 静态前缀（角色 + 红线，不含知识） */
function getFullStaticPrefixOptimized() {
    return `你是一个专业的社交聊天辅导AI，帮助用户分析对方消息并生成回复建议。你的核心方法论来自《魔鬼约会学》，严格按照以下知识体系运作。

# 红线禁忌

1. 对方明确拒绝时不得死缠烂打
2. 对方情绪不好（真生气/难过）时不使用扩大冲突
3. 不得生成涉及骚扰、强迫、不尊重的回复
4. 所有进攻型技巧的前提是对方的正面回应，没有正面回应就不能升级
5. 不要生成过于"油腻"或套路感过强的回复
6. 用表达自己来代替评价对方（安全法则）`;
}
/** 诊断驱动的回复生成 prompt（静态角色+红线 | 动态诊断+知识+上下文） */
function buildFullMessagesOptimized(params) {
    const { target, recentMessages, feedbackPreferences, diagnosis } = params;
    const chatHistory = formatChatHistory(recentMessages);
    // 知识选择：基于诊断的 knowledgeIds 精准加载
    const allUnits = (0, knowledge_1.getUnitsForMode)('full');
    let selectedUnits;
    if (diagnosis?.knowledgeIds?.length) {
        // 诊断路径：只用诊断指定的知识单元
        const unitMap = new Map(allUnits.map(u => [u.id, u]));
        selectedUnits = diagnosis.knowledgeIds
            .map(id => unitMap.get(id))
            .filter((u) => u !== undefined);
        // 确保核心单元 F01/F03 始终存在
        for (const coreId of CORE_UNIT_IDS) {
            if (!selectedUnits.some(u => u.id === coreId)) {
                const core = unitMap.get(coreId);
                if (core)
                    selectedUnits.unshift(core);
            }
        }
    }
    else {
        // 兜底：关键词匹配
        const lastHerMsg = [...recentMessages].reverse().find(m => m.role === 'her');
        selectedUnits = selectRelevantUnits(allUnits, lastHerMsg?.text || '', 'full');
    }
    const knowledge = formatSelectedKnowledge(selectedUnits, 'full');
    console.log(`[Prompt] Selected ${selectedUnits.length}/${allUnits.length} knowledge units via diagnosis: ${selectedUnits.map(u => u.id).join(',')}`);
    // 诊断摘要上下文
    const diagnosisSection = diagnosis ? `
## 当前诊断方案（已由军师分析确定，请严格遵循）

- 关系阶段：${diagnosis.stage}
- 对方态度：${diagnosis.attitude_level}
- 语言模式：${diagnosis.language_pattern}
- 情绪状态：${diagnosis.emotion_type}（${diagnosis.emotion_valence}）
- 推荐策略：${diagnosis.strategy}
- 下一步行动：${diagnosis.action}
- 升级条件：${diagnosis.upgrade_ready ? '✅ 满足' : '❌ 暂不满足'} — ${diagnosis.upgrade_reason}
${diagnosis.warnings?.length ? `- ⚠️ 注意事项：${diagnosis.warnings.join('；')}` : ''}
` : '';
    // 动态 system = 知识 + 诊断 + 上下文 + 输出要求
    const context = buildContextBlock(target, chatHistory, {
        '语气偏好': toneMapFull[target.tone_level] || '适中',
        '目标意图': goalMap[target.goal_intent] || '正在追求对方',
        '话题禁区': target.forbidden_topics || '无',
    });
    const feedback = feedbackPreferences ? `\n## 历史反馈偏好\n${feedbackPreferences}\n` : '';
    const dynamicContent = `# 知识体系\n\n${knowledge}\n
${diagnosisSection}
${context}
${feedback}# 输出要求

根据诊断方案，针对对方最新消息生成回复。只返回JSON：
{"replies":[{"id":1,"strategy":"策略名","text":"回复文本","reason":"推荐理由（1句话说明为什么符合诊断方向）","knowledgeId":"对应的知识单元ID"}]}

要求：
- 生成3-4条回复，风格各异，至少1条安全回复
- 所有回复必须符合诊断方案中的策略方向和注意事项
- 回复口语化自然，长度与对方发言匹配
- 每条标注策略名、理由和对应的知识单元ID
- 遵守语气偏好和话题禁区
- 基于历史反馈调整策略权重
- 只返回纯JSON，不要反引号markdown包裹，不要额外文字说明`;
    return [
        { role: 'system', content: getFullStaticPrefixOptimized() },
        { role: 'system', content: dynamicContent },
    ];
}
// ============ 工具函数 ============
const toneMapFull = {
    aggressive: '激进（大胆推进话题，适度冒险）',
    moderate: '适中（温和推进，保持舒适感）',
    conservative: '保守（稳扎稳打，避免冒犯）',
};
const toneMapQuick = {
    aggressive: '大胆推进',
    moderate: '温和适中',
    conservative: '稳扎稳打',
};
const goalMap = {
    practice: '只是练习聊天技巧',
    pursuing: '正在追求对方',
    friendship: '维持友谊关系',
};
function formatChatHistory(messages, limit) {
    const slice = limit ? messages.slice(-limit) : messages;
    return slice.map(m => {
        if (m.role === 'scene')
            return `【场景】${m.text}`;
        return `${m.role === 'her' ? '对方' : '我'}：${m.text}`;
    }).join('\n');
}
// ============ 知识格式化器 ============
function formatUnitForPrompt(unit, mode) {
    const sections = [];
    // I — 方法论骨架（所有模式都需要）
    sections.push(`#### ${unit.id} ${unit.title}`);
    sections.push(unit.interpretation);
    // E — 可执行步骤（full/quick/advisor）
    if (mode !== 'review' && unit.execution.length > 0) {
        sections.push('**操作步骤**：');
        for (const step of unit.execution) {
            let line = `${unit.execution.indexOf(step) + 1}. ${step.action}`;
            if (step.stopCondition) {
                line += `（判停：${step.stopCondition}）`;
            }
            sections.push(line);
        }
    }
    // A2 — 触发场景中属于当前模式的
    const relevantTriggers = unit.triggers.filter(t => t.modes.includes(mode));
    if (relevantTriggers.length > 0) {
        sections.push('**触发条件**：');
        for (const t of relevantTriggers) {
            const signals = t.languageSignals.length > 0 ? `（信号：${t.languageSignals.join('/')}）` : '';
            sections.push(`- ${t.scenario}${signals}`);
        }
    }
    // B — 边界（full/advisor 需要完整边界，quick 只需红线）
    if (mode === 'full' || mode === 'advisor') {
        if (unit.boundary.length > 0) {
            sections.push('**边界**：' + unit.boundary.join('；'));
        }
    }
    else if (mode === 'review') {
        // review 模式只需要关键边界
        if (unit.boundary.length > 0) {
            sections.push('**注意**：' + unit.boundary[0]);
        }
    }
    return sections.join('\n');
}
function formatKnowledgeSection(units, mode) {
    const frameworks = units.filter(u => u.type === 'framework');
    const principles = units.filter(u => u.type === 'principle');
    const scenarios = units.filter(u => u.type === 'scenario');
    const concepts = units.filter(u => u.type === 'concept');
    const sections = [];
    if (frameworks.length > 0) {
        sections.push('## 诊断与策略框架');
        for (const u of frameworks) {
            sections.push(formatUnitForPrompt(u, mode));
        }
    }
    if (principles.length > 0) {
        sections.push('## 关键原则');
        for (const u of principles) {
            sections.push(formatUnitForPrompt(u, mode));
        }
    }
    if (scenarios.length > 0) {
        sections.push('## 场景策略');
        for (const u of scenarios) {
            sections.push(formatUnitForPrompt(u, mode));
        }
    }
    if (concepts.length > 0) {
        sections.push('## 核心概念');
        for (const u of concepts) {
            sections.push(formatUnitForPrompt(u, mode));
        }
    }
    return sections.join('\n\n');
}
// ============ 通用上下文注入 ============
function buildContextBlock(target, chatHistory, extras) {
    const lines = [];
    lines.push(`## 对方人设`);
    lines.push(`名字：${target.name}`);
    if (target.meet_scene)
        lines.push(`认识场景：${target.meet_scene}`);
    if (target.persona)
        lines.push(`性格/人设：${target.persona}`);
    if (target.hobbies)
        lines.push(`兴趣爱好：${target.hobbies}`);
    if (target.recent_chats)
        lines.push(`近期聊天摘要：${target.recent_chats}`);
    if (extras) {
        for (const [k, v] of Object.entries(extras)) {
            if (v)
                lines.push(`${k}：${v}`);
        }
    }
    lines.push('');
    lines.push(`## 当前聊天记录`);
    lines.push(chatHistory || '（暂无聊天记录）');
    return lines.join('\n');
}
// ============ 四个 Prompt 构建函数 ============
function buildSystemPrompt(params) {
    const { target, recentMessages, planGoal, planNextStep, feedbackPreferences } = params;
    const chatHistory = formatChatHistory(recentMessages);
    const units = (0, knowledge_1.getUnitsForMode)('full');
    const knowledge = formatKnowledgeSection(units, 'full');
    const context = buildContextBlock(target, chatHistory, {
        '语气偏好': toneMapFull[target.tone_level] || '适中',
        '目标意图': goalMap[target.goal_intent] || '正在追求对方',
        '话题禁区': target.forbidden_topics || '无',
        '当前目标': planGoal || '探索阶段，建立舒适感',
        '下一步建议': planNextStep || '自然对话，寻找共同话题',
    });
    const feedback = feedbackPreferences ? `\n## 历史反馈偏好\n${feedbackPreferences}\n` : '';
    return `你是一个专业的社交聊天辅导AI，帮助用户分析对方消息并生成回复建议。你的核心方法论来自《魔鬼约会学》，严格按照以下知识体系运作。

# 知识体系

${knowledge}

# 红线禁忌

1. 对方明确拒绝时不得死缠烂打
2. 对方情绪不好（真生气/难过）时不使用扩大冲突
3. 不得生成涉及骚扰、强迫、不尊重的回复
4. 所有进攻型技巧的前提是对方的正面回应，没有正面回应就不能升级
5. 不要生成过于"油腻"或套路感过强的回复
6. 用表达自己来代替评价对方（安全法则）

${context}
${feedback}
# 输出要求

分析对方最新消息，返回JSON：
{"analysis":{"stage":"关系阶段（初期接触/聊天升温/暧昧期/约会恋爱期）","signal":"信号类型（正面冲突/正面无冲突/模糊/负面）","strategy":"推荐策略","signalText":"分析对方语气和隐含意思（2-3句）","emotions":["情绪标签1","情绪标签2"],"tip":"一句实用小建议","favorability":0-100,"favorabilityReason":"好感度判断依据（1-2句）","knowledgeIds":["用到的知识单元ID，如F01、F03"]},"plan":{"goal":"当前对话策略目标","nextStep":"下一步具体建议"},"replies":[{"id":1,"strategy":"策略名","text":"回复文本","reason":"推荐理由","knowledgeId":"对应的知识单元ID"}]}

要求：
- 生成3-4条回复，风格各异，至少1条安全回复
- 回复口语化自然，长度与对方发言匹配
- 每条标注策略名、理由和对应的知识单元ID
- 遵守语气偏好和话题禁区
- 基于历史反馈调整策略权重
- 只返回纯JSON，不要反引号markdown包裹，不要额外文字说明`;
}
// ============ 拆分版 Prompt 构建函数（用于 API Prompt Caching） ============
/** 构建动态上下文（每次请求变化的部分），作为第二条 system message */
function buildFullDynamicContext(params) {
    const { target, recentMessages, planGoal, planNextStep, feedbackPreferences } = params;
    const chatHistory = formatChatHistory(recentMessages);
    const context = buildContextBlock(target, chatHistory, {
        '语气偏好': toneMapFull[target.tone_level] || '适中',
        '目标意图': goalMap[target.goal_intent] || '正在追求对方',
        '话题禁区': target.forbidden_topics || '无',
        '当前目标': planGoal || '探索阶段，建立舒适感',
        '下一步建议': planNextStep || '自然对话，寻找共同话题',
    });
    const feedback = feedbackPreferences ? `\n## 历史反馈偏好\n${feedbackPreferences}\n` : '';
    return `${context}
${feedback}# 输出要求

分析对方最新消息，返回JSON：
{"analysis":{"stage":"关系阶段（初期接触/聊天升温/暧昧期/约会恋爱期）","signal":"信号类型（正面冲突/正面无冲突/模糊/负面）","strategy":"推荐策略","signalText":"分析对方语气和隐含意思（2-3句）","emotions":["情绪标签1","情绪标签2"],"tip":"一句实用小建议","favorability":0-100,"favorabilityReason":"好感度判断依据（1-2句）","knowledgeIds":["用到的知识单元ID，如F01、F03"]},"plan":{"goal":"当前对话策略目标","nextStep":"下一步具体建议"},"replies":[{"id":1,"strategy":"策略名","text":"回复文本","reason":"推荐理由","knowledgeId":"对应的知识单元ID"}]}

要求：
- 生成3-4条回复，风格各异，至少1条安全回复
- 回复口语化自然，长度与对方发言匹配
- 每条标注策略名、理由和对应的知识单元ID
- 遵守语气偏好和话题禁区
- 基于历史反馈调整策略权重
- 只返回纯JSON，不要反引号markdown包裹，不要额外文字说明`;
}
/** 构建拆分版的 full mode messages 数组（静态 + 动态分离） */
function buildFullMessages(params) {
    return [
        { role: 'system', content: getFullStaticPrefix() },
        { role: 'system', content: buildFullDynamicContext(params) },
    ];
}
/** 构建拆分版的 quick mode messages 数组（静态 + 动态分离） */
function buildQuickMessages(params) {
    const { target, recentMessages, feedbackPreferences, contextSummary } = params;
    const chatHistory = formatChatHistory(recentMessages, 4);
    const dynamicContext = `## 对方信息
名字：${target.name}
语气风格：${toneMapQuick[target.tone_level] || '温和适中'}${target.forbidden_topics ? `\n话题禁区：${target.forbidden_topics}` : ''}

${contextSummary ? `## 对话摘要\n${contextSummary}\n` : ''}${feedbackPreferences ? `## 用户偏好\n${feedbackPreferences}\n` : ''}
## 最近聊天
${chatHistory || '（暂无）'}

## 输出要求
严格返回JSON（短键名，不要多余字段）：
{"signal":"信号类型","fav":0-100,"ctx":"50字以内的对话摘要，概括关系阶段、对方态度、近期话题，供下次快速回忆","replies":[{"s":"策略名","t":"回复文本","kid":"知识单元ID"},{"s":"策略名","t":"回复文本","kid":"知识单元ID"},{"s":"策略名","t":"回复文本","kid":"知识单元ID"}]}

要求：
- signal可选值：正面冲突、正面无冲突、模糊、负面
- fav是好感度0-100数字
- ctx必须填写，50字以内
- 3条回复风格各不同，至少覆盖2种策略
- 回复口语化自然，长度与对方发言匹配
- 只返回纯JSON，不要反引号markdown包裹，不要额外文字说明`;
    return [
        { role: 'system', content: getQuickStaticPrefix() },
        { role: 'system', content: dynamicContext },
    ];
}
// ============ 原有完整版 Quick Prompt（保持向后兼容） ============
function buildQuickPrompt(params) {
    const { target, recentMessages, feedbackPreferences, contextSummary } = params;
    const chatHistory = formatChatHistory(recentMessages, 4);
    const units = (0, knowledge_1.getUnitsForMode)('quick');
    // quick 模式：精简知识，只保留 interpretation 的关键结论
    const knowledgeLines = [];
    knowledgeLines.push('## 快速参考');
    for (const u of units) {
        knowledgeLines.push(`**${u.id} ${u.title}**：${u.interpretation.split('\n')[0]}`);
        // 只取第一个触发场景的语言信号
        const trigger = u.triggers.find(t => t.modes.includes('quick'));
        if (trigger && trigger.languageSignals.length > 0) {
            knowledgeLines.push(`  信号：${trigger.languageSignals.join('、')}`);
        }
        // 只取前两个执行步骤
        if (u.execution.length > 0) {
            knowledgeLines.push(`  操作：${u.execution.slice(0, 2).map(s => s.action).join(' → ')}`);
        }
    }
    const context = `## 对方信息
名字：${target.name}
语气风格：${toneMapQuick[target.tone_level] || '温和适中'}${target.forbidden_topics ? `\n话题禁区：${target.forbidden_topics}` : ''}

${contextSummary ? `## 对话摘要\n${contextSummary}\n` : ''}${feedbackPreferences ? `## 用户偏好\n${feedbackPreferences}\n` : ''}
## 最近聊天
${chatHistory || '（暂无）'}`;
    return `你是社交聊天回复器。根据对方最新消息，快速生成3条回复。

${knowledgeLines.join('\n')}

## 红线
- 对方真生气→不用扩大冲突，改用共情
- 不生成油腻/套路感强的回复
- 遵守话题禁区

${context}

## 输出要求
严格返回JSON（短键名，不要多余字段）：
{"signal":"信号类型","fav":0-100,"ctx":"50字以内的对话摘要，概括关系阶段、对方态度、近期话题，供下次快速回忆","replies":[{"s":"策略名","t":"回复文本","kid":"知识单元ID"},{"s":"策略名","t":"回复文本","kid":"知识单元ID"},{"s":"策略名","t":"回复文本","kid":"知识单元ID"}]}

要求：
- signal可选值：正面冲突、正面无冲突、模糊、负面
- fav是好感度0-100数字
- ctx必须填写，50字以内
- 3条回复风格各不同，至少覆盖2种策略
- 回复口语化自然，长度与对方发言匹配
- 只返回纯JSON，不要反引号markdown包裹，不要额外文字说明`;
}
function buildAdvisorPrompt(params) {
    const { target, recentMessages, contextSummary } = params;
    const chatHistory = formatChatHistory(recentMessages, 20);
    const units = (0, knowledge_1.getUnitsForMode)('advisor');
    const knowledge = formatKnowledgeSection(units, 'advisor');
    return `你是一位资深的社交军师，擅长分析聊天对象的心理状态。你的方法论来自《魔鬼约会学》，严格按照以下知识体系进行分析。

# 分析知识体系

${knowledge}

# 诊断红线
- 不确定性要明确标注，不要过度推断
- 分析的是行为模式不是内心动机
- 数据不足时明确说明

# 对方信息
名字：${target.name}
性格：${target.persona || '未填写'}
兴趣：${target.hobbies || '未填写'}
关系目标：${target.goal_intent || '正在追求对方'}

${contextSummary ? `## 对话摘要\n${contextSummary}\n` : ''}
# 聊天记录
${chatHistory || '（暂无聊天记录）'}

# 输出要求
返回JSON：
{"attitude":{"level":"好感级别（回应/倾诉/关注/依顺）","languagePattern":"语言模式分析（上堆/下切比例+具体证据）","detail":"态度分析2-3句","evidence":"引用聊天记录中的具体内容作为依据"},"emotion":{"type":"情绪类型","valence":"正向/负向/中性","detail":"情绪分析2-3句","evidence":"引用具体证据"},"thought":{"intention":"对方可能的意图（标注置信度：高/中/低）","expectation":"对方可能期待什么","detail":"深入分析2-3句"},"diagnosis":{"warnings":["警告1（如诚意陷阱/真命天女症倾向/因果链放大情绪等）"],"stage":"当前关系层级","upgradeReady":true或false,"upgradeReason":"升级条件是否满足的判断依据","knowledgeIds":["分析中用到的知识单元ID"]},"nextStep":{"action":"建议的下一步具体行动","strategy":"推荐策略及对应知识单元ID","keyPoints":["要点1","要点2","要点3"],"warnings":["注意事项1","注意事项2"]}}

要求：
- evidence必须引用聊天记录中的具体内容
- nextStep要具体可执行，不要泛泛而谈
- warnings要指出用户可能犯的错误
- 如果聊天记录太少，在thought.detail中说明信息不足
- 只返回纯JSON，不要反引号markdown包裹，不要额外文字说明`;
}
function buildReviewPrompt(params) {
    const { target, recentMessages, replySelections } = params;
    const chatHistory = formatChatHistory(recentMessages, 30);
    const units = (0, knowledge_1.getUnitsForMode)('review');
    const knowledge = formatKnowledgeSection(units, 'review');
    const selectedReplies = replySelections.length > 0
        ? replySelections.map((s, i) => `${i + 1}. [${s.strategy || '自定义'}] ${s.reply_text}`).join('\n')
        : '（暂无选择记录）';
    return `你是一位社交聊天教练，擅长复盘用户的聊天表现。你的评价标准来自《魔鬼约会学》知识体系，逐轮对照以下知识检查用户的操作是否正确。

# 评估知识体系

${knowledge}

# 评估维度（5个维度，每维度1-5分）

1. **信号识别能力**：是否正确识别上堆/下切模式？是否区分聊天/见面信号？
2. **策略选择能力**：策略是否匹配信号类型？四大法则执行是否到位？
3. **关系节奏控制**：是否有越级操作？是否见好就收？是否走一步看一步？
4. **情绪管理能力**：是否陷入诚意陷阱？是否建因果链？是否就事论事？
5. **回应质量**：是否覆盖事实+情绪+认知？是否口语化自然？长度是否匹配？

# 对方信息
名字：${target.name}
性格：${target.persona || '未填写'}

# 聊天记录
${chatHistory || '（暂无聊天记录）'}

# 用户选择过的回复
${selectedReplies}

# 输出要求
返回JSON：
{"highlights":[{"round":1,"action":"用户做了什么","whyGood":"为什么做得好（引用知识单元ID）","tip":"如何保持和加强"}],"mistakes":[{"round":2,"action":"用户做了什么","whyBad":"为什么不好（引用知识单元ID）","better":"更好的做法（给出具体替代回复）"}],"scores":{"signalRecognition":1-5,"strategySelection":1-5,"rhythmControl":1-5,"emotionManagement":1-5,"responseQuality":1-5},"overall":{"total":0-100,"summary":"总体表现评价2-3句","strengths":["优势1","优势2"],"weaknesses":["待提升1","待提升2"],"advice":"进阶建议2-3句","warningLevel":"green/yellow/red","knowledgeGaps":["用户最需要学习的知识单元ID"]}}

要求：
- highlights至少2条，多多益善
- mistakes至少1条
- round指第几轮对话（从1开始）
- better必须给出具体的替代回复文本
- scores每个维度独立评分
- overall.total是五维平均分×20
- warningLevel：green=状态健康 yellow=需要调整 red=存在诚意陷阱或真命天女症倾向
- knowledgeGaps：指出用户最需要补强的1-3个知识单元
- 如果聊天记录太少（不足3轮），在summary中提示信息不足
- 只返回纯JSON，不要反引号markdown包裹，不要额外文字说明`;
}
